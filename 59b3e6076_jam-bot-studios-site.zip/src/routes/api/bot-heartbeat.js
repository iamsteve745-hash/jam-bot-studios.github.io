import { createFileRoute } from "@tanstack/react-router";

// Called by the bot itself (running on your own VPS / host) every ~30 seconds.
// This is what makes the panel show a real ONLINE status — nothing is faked.
export const Route = createFileRoute("/api/bot-heartbeat")({
  server: {
    handlers: {
      POST: async ({ request, context }) => {
        let body;
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "Invalid JSON" }, { status: 400 });
        }
        const botId = typeof body?.bot_id === "string" ? body.bot_id.slice(0, 64) : "";
        const secret = typeof body?.secret === "string" ? body.secret.slice(0, 128) : "";
        const status = ["online", "starting", "error", "offline"].includes(body?.status) ? body.status : "online";
        const message = typeof body?.message === "string" ? body.message.slice(0, 500) : "";

        if (!botId || !secret) return Response.json({ error: "bot_id and secret are required" }, { status: 400 });

        const base44 = context.getBase44();
        const svc = base44.asServiceRole;
        const bot = await svc.entities.Bot.get(botId).catch(() => null);
        if (!bot || !bot.heartbeat_secret || bot.heartbeat_secret !== secret) {
          return Response.json({ error: "Unauthorized" }, { status: 401 });
        }

        const now = new Date().toISOString();
        const patch = { status, last_seen: now };
        if (status === "online") {
          patch.last_connected = now;
          patch.last_error = "";
          if (bot.status !== "online") patch.restarts = (bot.restarts || 0) + (bot.last_seen ? 1 : 0);
        }
        if (status === "error") patch.last_error = message || "Bot reported an error";

        await svc.entities.Bot.update(bot.id, patch);

        if (bot.status !== status) {
          const kind = status === "online" ? (bot.status === "offline" ? "reconnected" : "started") : status === "error" ? "crashed" : "disconnected";
          await svc.entities.BotEvent.create({
            bot_id: bot.id,
            kind,
            level: status === "error" ? "error" : status === "offline" ? "warn" : "info",
            message: message || `Bot reported ${status}`,
          });
        }

        return Response.json({ ok: true, status });
      },
    },
  },
});