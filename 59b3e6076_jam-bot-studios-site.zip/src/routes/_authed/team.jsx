import { createFileRoute, redirect, useRouter } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";
import { getTeam } from "@/lib/server-fns";
import InviteStaffForm from "@/components/team/InviteStaffForm";
import StaffRoster from "@/components/team/StaffRoster";

export const Route = createFileRoute("/_authed/team")({
  head: () => ({ meta: [{ title: "Team & staff — Jam Bot Studios" }] }),
  beforeLoad: ({ context }) => {
    if (context?.user && context.user.role !== "admin") throw redirect({ to: "/portfolio" });
  },
  loader: () => getTeam(),
  component: TeamPage,
});

function TeamPage() {
  const team = Route.useLoaderData();
  const router = useRouter();
  const refresh = () => router.invalidate();

  return (
    <div className="space-y-6">
      <header>
        <p className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-[0.18em] text-violet-300">
          <ShieldCheck className="h-3.5 w-3.5" /> Owner only
        </p>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight text-foreground">Team &amp; staff</h1>
        <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          Add people you trust as admins so they can handle orders, tickets and bots. They can work the
          studio day to day — adding and removing admins stays with you.
        </p>
      </header>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,340px)_minmax(0,1fr)] lg:items-start">
        {team.is_owner ? (
          <InviteStaffForm onDone={refresh} />
        ) : (
          <div className="rounded-2xl border border-border bg-card/70 p-5">
            <h2 className="text-sm font-semibold text-foreground">Owner only</h2>
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
              You can see who has access, but only the studio owner can add or remove admins.
            </p>
          </div>
        )}
        <StaffRoster team={team} onDone={refresh} />
      </div>
    </div>
  );
}