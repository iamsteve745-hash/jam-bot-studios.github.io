import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Plus, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import StatusPill from "@/components/StatusPill";

export const Route = createFileRoute("/_authed/orders/")({
  head: () => ({ meta: [{ title: "My orders — Jam Bot Studios" }] }),
  component: MyOrders,
});

function MyOrders() {
  const [orders, setOrders] = useState(null);

  useEffect(() => {
    let alive = true;
    base44.entities.BotOrder.list({ sort: "-created_date", limit: 50 })
      .then((page) => alive && setOrders(page.items || []))
      .catch(() => alive && setOrders([]));
    return () => {
      alive = false;
    };
  }, []);

  return (
    <div className="mx-auto max-w-4xl">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">My orders</h1>
          <p className="mt-1 text-sm text-muted-foreground">Every request you've submitted, with its live status.</p>
        </div>
        <Link
          to="/request"
          className="inline-flex items-center gap-2 rounded-xl bg-violet-500 px-4 py-2 text-xs font-semibold text-black transition hover:bg-violet-400"
        >
          <Plus className="h-3.5 w-3.5" /> New request
        </Link>
      </div>

      {orders === null ? (
        <div className="mt-10 flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading your orders…
        </div>
      ) : orders.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center">
          <p className="text-sm font-medium">No orders yet</p>
          <p className="mt-1 text-xs text-muted-foreground">Describe the bot you want and we'll take it from there.</p>
          <Link
            to="/request"
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-violet-500 px-4 py-2 text-xs font-semibold text-black transition hover:bg-violet-400"
          >
            Request a bot <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {orders.map((o) => (
            <Link
              key={o.id}
              to="/orders/$orderId"
              params={{ orderId: o.id }}
              className="flex flex-wrap items-center gap-4 rounded-2xl border border-border bg-card/60 p-4 transition hover:border-violet-500/30 hover:bg-card"
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate text-sm font-semibold">{o.bot_name}</p>
                  <span className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                    {o.order_code}
                  </span>
                </div>
                <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{o.description}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[11px] text-muted-foreground">
                  {o.created_date ? new Date(o.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : ""}
                </span>
                <StatusPill status={o.status} />
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}