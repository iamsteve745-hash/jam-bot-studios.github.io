import { useEffect, useState } from "react";
import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { Loader2, Search, ArrowRight, Bot as BotIcon } from "lucide-react";
import { base44 } from "@/api/base44Client";
import StatusPill from "@/components/StatusPill";

export const Route = createFileRoute("/_authed/bots/")({
  head: () => ({ meta: [{ title: "Bot manager — Jam Bot Studios" }] }),
  beforeLoad: ({ context }) => {
    if (context?.user && context.user.role !== "admin") throw redirect({ to: "/portfolio" });
  },
  component: BotManager,
});

const FILTERS = ["all", "online", "offline", "error", "starting", "deploying"];

function BotManager() {
  const [bots, setBots] = useState(null);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");

  const load = () => base44.entities.Bot.list({ sort: "-created_date", limit: 100 }).then((p) => setBots(p.items || [])).catch(() => setBots([]));

  useEffect(() => {
    load();
    const unsub = base44.entities.Bot.subscribe(() => load());
    return unsub;
  }, []);

  const visible = (bots || []).filter((b) => {
    const okStatus = filter === "all" || b.status === filter;
    const q = query.trim().toLowerCase();
    const okQuery =
      !q ||
      b.name?.toLowerCase().includes(q) ||
      b.customer_email?.toLowerCase().includes(q) ||
      b.discord_bot_id?.includes(q) ||
      b.customer_name?.toLowerCase().includes(q);
    return okStatus && okQuery;
  });

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Bot manager</h1>
          <p className="mt-1 text-sm text-muted-foreground">Every bot built through the studio, with its live health.</p>
        </div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search name, customer or bot ID"
            className="w-64 rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-xs outline-none focus:border-violet-500/60"
          />
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-1.5">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-lg px-3 py-1.5 text-[11px] font-medium capitalize transition ${
              filter === f ? "bg-violet-500/15 text-violet-200 ring-1 ring-inset ring-violet-400/25" : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {bots === null ? (
        <div className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading bots…
        </div>
      ) : visible.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-border p-10 text-center">
          <BotIcon className="mx-auto h-6 w-6 text-muted-foreground" />
          <p className="mt-2 text-sm font-medium">No bots here yet</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Open an accepted order and use “Generate bot with AI” to create the first project.
          </p>
          <Link to="/admin/orders" className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-violet-300">
            Go to orders <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      ) : (
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((b) => (
            <Link
              key={b.id}
              to="/bots/$botId"
              params={{ botId: b.id }}
              className="group rounded-2xl border border-border bg-card/60 p-4 transition hover:-translate-y-0.5 hover:border-violet-500/30"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-violet-300">
                    <BotIcon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{b.name}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{b.customer_name || b.customer_email || "—"}</p>
                  </div>
                </div>
                <StatusPill status={b.status} kind="bot" />
              </div>
              <dl className="mt-4 grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <dt className="text-muted-foreground">Bot ID</dt>
                  <dd className="truncate font-mono text-foreground/80">{b.discord_bot_id || "not linked"}</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Host</dt>
                  <dd className="truncate text-foreground/80">{b.hosting_provider || "external"}</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Created</dt>
                  <dd className="text-foreground/80">
                    {b.created_date ? new Date(b.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Last deploy</dt>
                  <dd className="text-foreground/80">
                    {b.last_deploy_at ? new Date(b.last_deploy_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "never"}
                  </dd>
                </div>
              </dl>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}