import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import {
  ArrowLeft,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Download,
  FileCode2,
  Rocket,
  Copy,
  AlertTriangle,
  Activity,
  Clock,
  RotateCw,
  Power,
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import StatusPill from "@/components/StatusPill";
import { checkBotHealth, deployBot, logBotEvent, refreshBots } from "@/lib/server-fns";
import { downloadZip } from "@/lib/zip";

export const Route = createFileRoute("/_authed/bots/$botId")({
  head: () => ({ meta: [{ title: "Bot monitor — Jam Bot Studios" }] }),
  component: BotMonitor,
});

const MAINTENANCE_BIO = "Down for maintenance. We will be back up as soon as possible. Sorry for the inconvenience.";

function BotMonitor() {
  const { botId } = Route.useParams();
  const [bot, setBot] = useState(null);
  const [events, setEvents] = useState([]);
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState("");
  const [loading, setLoading] = useState(true);

  const health = useServerFn(checkBotHealth);
  const deploy = useServerFn(deployBot);
  const refresh = useServerFn(refreshBots);
  const logEvent = useServerFn(logBotEvent);

  const load = async () => {
    try {
      const [b, ev, fl] = await Promise.all([
        base44.entities.Bot.get(botId),
        base44.entities.BotEvent.filter({ bot_id: botId }, { sort: "-created_date", limit: 40 }),
        base44.entities.BotFile.filter({ bot_id: botId }),
      ]);
      setBot(b);
      setEvents(ev.items || []);
      setFiles(fl || []);
    } catch {
      setBot(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.Bot.subscribe((e) => {
      if (e?.data?.id === botId) load();
    });
    return unsub;
  }, [botId]);

  const runHealth = async () => {
    setBusy("health");
    try {
      const res = await health({ data: { bot_id: botId } });
      if (res.ok) toast.success(`Token valid — connected as ${res.username}`);
      else toast.error(res.reason || "Discord did not accept the token");
      await load();
    } catch (err) {
      toast.error(err?.message || "Could not reach Discord");
    } finally {
      setBusy("");
    }
  };

  const runDeploy = async () => {
    setBusy("deploy");
    try {
      const res = await deploy({ data: { bot_id: botId, provider: bot.hosting_provider || "External host" } });
      if (res.pushed) toast.success("Deploy webhook accepted");
      else toast.warning(res.reason || "Recorded locally — no deploy webhook configured");
      await load();
    } catch (err) {
      toast.error(err?.message || "Deployment failed");
    } finally {
      setBusy("");
    }
  };

  const runRefresh = async () => {
    setBusy("refresh");
    try {
      await refresh();
      await load();
      toast.success("Statuses refreshed");
    } finally {
      setBusy("");
    }
  };

  const toggleMaintenance = async () => {
    setBusy("maint");
    try {
      await logEvent({
        data: {
          bot_id: botId,
          kind: "maintenance",
          level: bot.maintenance ? "info" : "warn",
          message: bot.maintenance ? "Maintenance mode cleared." : "Maintenance mode set manually.",
          maintenance: !bot.maintenance,
        },
      });
      await load();
    } catch (err) {
      toast.error(err?.message || "Could not update maintenance mode");
    } finally {
      setBusy("");
    }
  };

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied");
    } catch {
      toast.error("Copy failed — select the text manually");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading bot…
      </div>
    );
  }

  if (!bot) {
    return (
      <div className="rounded-2xl border border-border bg-card/60 p-8 text-center">
        <p className="text-sm font-medium">Bot not found</p>
        <Link to="/bots" className="mt-3 inline-block text-xs font-semibold text-violet-300">
          Back to bot manager
        </Link>
      </div>
    );
  }

  const panelUrl = typeof window !== "undefined" ? window.location.origin : "";
  const envSnippet = `PANEL_URL=${panelUrl}\nBOT_ID=${bot.id}\nBOT_SECRET=${bot.heartbeat_secret || ""}`;

  return (
    <div className="space-y-6">
      <Link to="/bots" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-3.5 w-3.5" /> Bot manager
      </Link>

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{bot.name}</h1>
            <StatusPill status={bot.status} kind="bot" />
            {bot.maintenance && (
              <span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-[11px] font-medium text-amber-300 ring-1 ring-inset ring-amber-400/25">
                Maintenance mode
              </span>
            )}
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            {bot.customer_name || bot.customer_email || "No customer"} · bot ID{" "}
            <span className="font-mono">{bot.discord_bot_id || "not linked"}</span>
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={runHealth}
            disabled={busy === "health"}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-medium transition hover:border-violet-500/40 disabled:opacity-60"
          >
            {busy === "health" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldCheck className="h-3.5 w-3.5 text-emerald-300" />}
            Check Discord token
          </button>
          <button
            onClick={runRefresh}
            disabled={busy === "refresh"}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-medium transition hover:border-violet-500/40 disabled:opacity-60"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${busy === "refresh" ? "animate-spin" : ""}`} /> Refresh
          </button>
          <button
            onClick={() => downloadZip(files.map((f) => ({ path: f.path, content: f.content })), bot.name)}
            disabled={!files.length}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-medium transition hover:border-violet-500/40 disabled:opacity-40"
          >
            <Download className="h-3.5 w-3.5" /> Download
          </button>
          <Link
            to="/bots/$botId/editor"
            params={{ botId: bot.id }}
            className="inline-flex items-center gap-2 rounded-xl bg-violet-500 px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-violet-400"
          >
            <FileCode2 className="h-3.5 w-3.5" /> Code editor
          </Link>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Status", value: bot.status, icon: Activity },
          { label: "Last seen", value: bot.last_seen ? new Date(bot.last_seen).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }) : "never", icon: Clock },
          { label: "Last connected", value: bot.last_connected ? new Date(bot.last_connected).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "never", icon: ShieldCheck },
          { label: "Restarts", value: bot.restarts || 0, icon: RotateCw },
        ].map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="rounded-2xl border border-border bg-card/60 p-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">{c.label}</span>
                <Icon className="h-4 w-4 text-violet-300" />
              </div>
              <p className="mt-2 truncate text-sm font-medium capitalize">{c.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-2xl border border-border bg-card/60 p-4">
          <h2 className="text-sm font-semibold">Discord connection</h2>
          <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
            The bot runs on your own host. The panel knows it is online because the bot posts a heartbeat every 30
            seconds — no fake statuses.
          </p>
          <dl className="mt-3 space-y-2 text-xs">
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">Token status</dt>
              <dd className="font-medium">{bot.token_status || "not configured"}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">Secret name</dt>
              <dd className="font-mono text-[11px]">{bot.token_secret_name || "—"}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">Hosting</dt>
              <dd className="font-medium">{bot.hosting_provider || "External host"}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted-foreground">Last deploy</dt>
              <dd className="font-medium">{bot.last_deploy_at ? new Date(bot.last_deploy_at).toLocaleString("en-US") : "never"}</dd>
            </div>
          </dl>
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              onClick={runDeploy}
              disabled={busy === "deploy"}
              className="inline-flex items-center gap-2 rounded-xl bg-violet-500 px-3 py-2 text-xs font-semibold text-black transition hover:bg-violet-400 disabled:opacity-60"
            >
              {busy === "deploy" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Rocket className="h-3.5 w-3.5" />}
              Deploy
            </button>
            <button
              onClick={toggleMaintenance}
              disabled={busy === "maint"}
              className="inline-flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-xs font-medium transition hover:border-amber-400/40 disabled:opacity-60"
            >
              <Power className="h-3.5 w-3.5" /> {bot.maintenance ? "Clear maintenance" : "Set maintenance"}
            </button>
          </div>
          {bot.last_error && <p className="mt-3 rounded-lg bg-red-500/10 p-2.5 text-[11px] text-red-300">{bot.last_error}</p>}
        </section>

        <section className="rounded-2xl border border-border bg-card/60 p-4">
          <h2 className="text-sm font-semibold">Heartbeat setup</h2>
          <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
            Add these to the bot's <span className="font-mono">.env</span> and run{" "}
            <span className="font-mono">heartbeat.heartbeat_loop()</span> as a background task.
          </p>
          <pre className="mt-3 overflow-x-auto rounded-xl bg-black/40 p-3 font-mono text-[11px] leading-relaxed text-foreground/80">
{envSnippet}
          </pre>
          <button
            onClick={() => copy(envSnippet)}
            className="mt-2 inline-flex items-center gap-1.5 text-[11px] font-medium text-violet-300 hover:text-violet-200"
          >
            <Copy className="h-3 w-3" /> Copy env block
          </button>
          <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">
            The heartbeat secret is not a bot token — it only lets this bot report its status.
          </p>
        </section>
      </div>

      <section className="rounded-2xl border border-amber-500/25 bg-amber-500/[0.06] p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
          <div>
            <h2 className="text-sm font-semibold text-amber-200">Automatic “About me” maintenance bio is not possible</h2>
            <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
              Discord's API does not expose a bot's About Me field, so the panel will not pretend to change it. Update it
              by hand in the Developer Portal and record the change here.
            </p>
            <div className="mt-3 rounded-xl bg-black/30 p-3 font-mono text-[11px] text-foreground/80">{MAINTENANCE_BIO}</div>
            <div className="mt-2 flex flex-wrap gap-2">
              <button onClick={() => copy(MAINTENANCE_BIO)} className="inline-flex items-center gap-1.5 text-[11px] font-medium text-amber-200">
                <Copy className="h-3 w-3" /> Copy bio
              </button>
              <button
                onClick={async () => {
                  await logEvent({
                    data: { bot_id: botId, kind: "maintenance", level: "info", message: "Maintenance bio applied manually." },
                  });
                  await load();
                  toast.success("Logged");
                }}
                className="inline-flex items-center gap-1.5 text-[11px] font-medium text-amber-200"
              >
                <ShieldCheck className="h-3 w-3" /> Mark bio applied
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card/60">
        <div className="border-b border-border px-4 py-3">
          <h2 className="text-sm font-semibold">Monitoring log</h2>
        </div>
        <ul className="max-h-80 divide-y divide-border overflow-y-auto thin-scroll">
          {events.length === 0 && <li className="p-4 text-xs text-muted-foreground">No events yet.</li>}
          {events.map((e) => (
            <li key={e.id} className="flex flex-wrap items-center gap-3 px-4 py-2.5 text-xs">
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  e.level === "error" ? "bg-red-400" : e.level === "warn" ? "bg-amber-400" : "bg-violet-400"
                }`}
              />
              <span className="rounded-md bg-secondary px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                {e.kind}
              </span>
              <span className="text-foreground/85">{e.message}</span>
              <span className="ml-auto text-[10px] text-muted-foreground">
                {e.created_date ? new Date(e.created_date).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : ""}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}