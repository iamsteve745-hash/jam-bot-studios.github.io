import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import {
  ArrowLeft,
  Loader2,
  Sparkles,
  Bot as BotIcon,
  Save,
  Paperclip,
  FileCode2,
  ShieldCheck,
  ShieldAlert,
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import StatusPill from "@/components/StatusPill";
import TicketThread from "@/components/TicketThread";
import { generateBotProject, updateOrderStatus } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/orders/$orderId")({
  head: () => ({ meta: [{ title: "Order ticket — Jam Bot Studios" }] }),
  component: OrderTicket,
});

const STATUSES = ["pending", "accepted", "in_development", "testing", "completed", "denied"];

function OrderTicket() {
  const { orderId } = Route.useParams();
  const { user } = useAuth();
  const isOwner = user?.role === "admin";
  const [order, setOrder] = useState(null);
  const [bot, setBot] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [draft, setDraft] = useState({ status: "pending", progress: 0, price: "", timeline: "", admin_notes: "" });
  const [aiResult, setAiResult] = useState(null);

  const saveStatus = useServerFn(updateOrderStatus);
  const generate = useServerFn(generateBotProject);

  const load = async () => {
    try {
      const o = await base44.entities.BotOrder.get(orderId);
      setOrder(o);
      setDraft({
        status: o.status || "pending",
        progress: o.progress || 0,
        price: o.price || "",
        timeline: o.timeline || "",
        admin_notes: o.admin_notes || "",
      });
      const bots = await base44.entities.Bot.filter({ order_id: orderId });
      setBot(bots[0] || null);
    } catch {
      setOrder(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [orderId]);

  const applyStatus = async () => {
    setBusy("status");
    try {
      await saveStatus({
        data: {
          order_id: orderId,
          status: draft.status,
          progress: Number(draft.progress) || 0,
          price: draft.price,
          timeline: draft.timeline,
          admin_notes: draft.admin_notes,
        },
      });
      toast.success("Order updated");
      await load();
    } catch (err) {
      toast.error(err?.message || "Could not update the order");
    } finally {
      setBusy("");
    }
  };

  const runAI = async () => {
    setBusy("ai");
    setAiResult(null);
    try {
      const result = await generate({ data: { order_id: orderId } });
      setAiResult(result);
      toast.success(`Generated ${result.file_count} files`);
      await load();
    } catch (err) {
      toast.error(err?.message || "Generation failed");
    } finally {
      setBusy("");
    }
  };

  const openReferences = async () => {
    for (const uri of order?.reference_files || []) {
      try {
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: uri, expires_in: 600 });
        window.open(signed_url, "_blank", "noopener");
      } catch {
        toast.error("A reference file could not be opened");
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Opening ticket…
      </div>
    );
  }

  if (!order) {
    return (
      <div className="rounded-2xl border border-border bg-card/60 p-8 text-center">
        <p className="text-sm font-medium">This ticket isn't available</p>
        <p className="mt-1 text-xs text-muted-foreground">It may belong to another account.</p>
        <Link to="/orders" className="mt-4 inline-block text-xs font-semibold text-violet-300">
          Back to my orders
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Link to={isOwner ? "/admin/orders" : "/orders"} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-3.5 w-3.5" /> {isOwner ? "All orders" : "My orders"}
      </Link>

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{order.bot_name}</h1>
            <span className="rounded-md bg-secondary px-2 py-1 font-mono text-[11px] text-muted-foreground">{order.order_code}</span>
            <StatusPill status={order.status} />
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            {order.discord_username || "Customer"} · submitted{" "}
            {order.created_date ? new Date(order.created_date).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : ""}
          </p>
        </div>
        {bot && (
          <Link
            to="/bots/$botId"
            params={{ botId: bot.id }}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3.5 py-2 text-xs font-medium transition hover:border-violet-500/40"
          >
            <BotIcon className="h-3.5 w-3.5 text-violet-300" /> Open bot
          </Link>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="space-y-6">
          <section className="rounded-2xl border border-border bg-card/60 p-5">
            <h2 className="text-sm font-semibold">The request</h2>
            <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{order.description}</p>
            {order.features && (
              <div className="mt-4">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Features & commands</p>
                <p className="mt-1.5 whitespace-pre-wrap text-sm text-foreground/80">{order.features}</p>
              </div>
            )}
            {order.extra_requirements && (
              <div className="mt-4">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Additional notes</p>
                <p className="mt-1.5 whitespace-pre-wrap text-sm text-foreground/80">{order.extra_requirements}</p>
              </div>
            )}
            <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-border pt-4 text-[11px] text-muted-foreground">
              <span>Server ID: {order.server_id || "not provided"}</span>
              {!!(order.reference_files || []).length && (
                <button onClick={openReferences} className="inline-flex items-center gap-1.5 text-violet-300 hover:text-violet-200">
                  <Paperclip className="h-3 w-3" /> {order.reference_files.length} reference file(s)
                </button>
              )}
            </div>
          </section>

          {bot && (
            <section className="rounded-2xl border border-border bg-card/60 p-5">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold">Bot status</h2>
                <StatusPill status={bot.status} kind="bot" />
              </div>
              {isOwner ? (
                <div className="mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2">
                  <p>Discord ID: <span className="font-mono text-foreground">{bot.discord_bot_id || "—"}</span></p>
                  <p>Last seen: {bot.last_seen ? new Date(bot.last_seen).toLocaleString("en-US") : "never"}</p>
                  <p>Restarts: {bot.restarts || 0}</p>
                  <p>Token: {bot.token_status || "not configured"}</p>
                </div>
              ) : (
                <div
                  className={`mt-3 flex items-center gap-3 rounded-xl p-3 text-sm ${
                    bot.status === "online" ? "bg-emerald-500/10 text-emerald-200" : "bg-red-500/10 text-red-200"
                  }`}
                >
                  {bot.status === "online" ? <ShieldCheck className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
                  {bot.status === "online"
                    ? "Your bot is operational and working normally."
                    : "Your bot is currently offline. We're on it."}
                </div>
              )}
            </section>
          )}

          {isOwner && aiResult && (
            <section className="rounded-2xl border border-violet-500/25 bg-violet-500/[0.07] p-5">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-violet-200">
                <Sparkles className="h-4 w-4" /> AI build summary
              </h2>
              <p className="mt-2 text-sm text-foreground/85">{aiResult.summary}</p>
              {!!aiResult.setup_steps?.length && (
                <ol className="mt-3 list-decimal space-y-1 pl-5 text-xs text-muted-foreground">
                  {aiResult.setup_steps.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ol>
              )}
              <Link
                to="/bots/$botId/editor"
                params={{ botId: aiResult.bot_id }}
                className="mt-4 inline-flex items-center gap-2 rounded-xl bg-violet-500 px-3.5 py-2 text-xs font-semibold text-black hover:bg-violet-400"
              >
                <FileCode2 className="h-3.5 w-3.5" /> Open the code editor
              </Link>
            </section>
          )}

          <TicketThread orderId={order.id} isOwner={isOwner} />
        </div>

        <aside className="space-y-4">
          {isOwner ? (
            <>
              <div className="rounded-2xl border border-border bg-card/60 p-4">
                <h2 className="text-sm font-semibold">Manage order</h2>
                <label className="mt-3 block">
                  <span className="mb-1 block text-[11px] uppercase tracking-wider text-muted-foreground">Status</span>
                  <select
                    value={draft.status}
                    onChange={(e) => setDraft((d) => ({ ...d, status: e.target.value }))}
                    className="w-full rounded-lg border border-input bg-background px-2.5 py-2 text-sm outline-none focus:border-violet-500/60"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {s.replace(/_/g, " ")}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="mt-3 block">
                  <span className="mb-1 block text-[11px] uppercase tracking-wider text-muted-foreground">
                    Progress · {draft.progress}%
                  </span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={draft.progress}
                    onChange={(e) => setDraft((d) => ({ ...d, progress: e.target.value }))}
                    className="w-full accent-violet-500"
                  />
                </label>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <input
                    value={draft.price}
                    onChange={(e) => setDraft((d) => ({ ...d, price: e.target.value }))}
                    placeholder="Price"
                    className="rounded-lg border border-input bg-background px-2.5 py-2 text-xs outline-none focus:border-violet-500/60"
                  />
                  <input
                    value={draft.timeline}
                    onChange={(e) => setDraft((d) => ({ ...d, timeline: e.target.value }))}
                    placeholder="Timeline"
                    className="rounded-lg border border-input bg-background px-2.5 py-2 text-xs outline-none focus:border-violet-500/60"
                  />
                </div>
                <textarea
                  rows={3}
                  value={draft.admin_notes}
                  onChange={(e) => setDraft((d) => ({ ...d, admin_notes: e.target.value }))}
                  placeholder="Internal notes"
                  className="mt-2 w-full rounded-lg border border-input bg-background px-2.5 py-2 text-xs outline-none focus:border-violet-500/60"
                />
                <button
                  onClick={applyStatus}
                  disabled={busy === "status"}
                  className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-violet-500 px-3 py-2 text-xs font-semibold text-black transition hover:bg-violet-400 disabled:opacity-60"
                >
                  {busy === "status" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                  Save changes
                </button>
              </div>

              <div className="rounded-2xl border border-violet-500/25 bg-gradient-to-b from-violet-500/10 to-transparent p-4">
                <h2 className="flex items-center gap-2 text-sm font-semibold text-violet-200">
                  <Sparkles className="h-4 w-4" /> Generate with AI
                </h2>
                <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">
                  Reads the whole request and writes a complete discord.py project — slash commands, views, database,
                  requirements, README and the heartbeat file.
                </p>
                <button
                  onClick={runAI}
                  disabled={busy === "ai"}
                  className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-violet-500 px-3 py-2.5 text-xs font-semibold text-black transition hover:bg-violet-400 disabled:opacity-60"
                >
                  {busy === "ai" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                  {busy === "ai" ? "Generating project…" : bot ? "Regenerate project" : "Generate bot with AI"}
                </button>
              </div>
            </>
          ) : (
            <div className="rounded-2xl border border-border bg-card/60 p-4">
              <h2 className="text-sm font-semibold">Order details</h2>
              <dl className="mt-3 space-y-2 text-xs">
                <div className="flex justify-between gap-3">
                  <dt className="text-muted-foreground">Status</dt>
                  <dd><StatusPill status={order.status} /></dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-muted-foreground">Progress</dt>
                  <dd className="font-medium">{order.progress || 0}%</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-muted-foreground">Price</dt>
                  <dd className="font-medium">{order.price || "to be quoted"}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-muted-foreground">Timeline</dt>
                  <dd className="font-medium">{order.timeline || "to be confirmed"}</dd>
                </div>
              </dl>
              <p className="mt-4 rounded-lg bg-secondary/60 p-2.5 text-[11px] leading-relaxed text-muted-foreground">
                You'll never see bot tokens or source code here. Ask anything in the ticket below.
              </p>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}