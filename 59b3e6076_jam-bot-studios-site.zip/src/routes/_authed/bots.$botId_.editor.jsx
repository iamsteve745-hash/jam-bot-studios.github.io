import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import {
  ArrowLeft,
  Loader2,
  Save,
  Download,
  Plus,
  Trash2,
  Pencil,
  Sparkles,
  History,
  X,
  FileCode2,
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import CodeEditor from "@/components/CodeEditor";
import { aiEditFile } from "@/lib/server-fns";
import { downloadZip } from "@/lib/zip";

export const Route = createFileRoute("/_authed/bots/$botId_/editor")({
  head: () => ({ meta: [{ title: "Code editor — Jam Bot Studios" }] }),
  component: BotEditor,
});

function BotEditor() {
  const { botId } = Route.useParams();
  const [bot, setBot] = useState(null);
  const [files, setFiles] = useState([]);
  const [selected, setSelected] = useState(null);
  const [draft, setDraft] = useState("");
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState("");
  const [instruction, setInstruction] = useState("");
  const [versions, setVersions] = useState([]);
  const [showVersions, setShowVersions] = useState(false);
  const [newPath, setNewPath] = useState("");
  const [renaming, setRenaming] = useState("");
  const [loading, setLoading] = useState(true);

  const aiEdit = useServerFn(aiEditFile);

  const current = useMemo(() => files.find((f) => f.id === selected) || null, [files, selected]);

  const load = async (keepId) => {
    const [b, fl] = await Promise.all([base44.entities.Bot.get(botId), base44.entities.BotFile.filter({ bot_id: botId })]);
    setBot(b);
    const sorted = [...fl].sort((a, b2) => a.path.localeCompare(b2.path));
    setFiles(sorted);
    const next = keepId ? sorted.find((f) => f.id === keepId) : sorted[0];
    if (next) {
      setSelected(next.id);
      setDraft(next.content || "");
      setDirty(false);
    } else {
      setSelected(null);
      setDraft("");
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [botId]);

  const pick = (file) => {
    if (dirty && !window.confirm("Discard unsaved changes?")) return;
    setSelected(file.id);
    setDraft(file.content || "");
    setDirty(false);
    setShowVersions(false);
  };

  const save = async (content, source = "manual") => {
    if (!current) return;
    setBusy("save");
    try {
      await base44.entities.BotFileVersion.create({
        bot_id: botId,
        path: current.path,
        content: current.content || "",
        version: current.version || 1,
        source,
      });
      await base44.entities.BotFile.update(current.id, { content, version: (current.version || 1) + 1 });
      await base44.entities.BotEvent.create({
        bot_id: botId,
        kind: "code_updated",
        level: "info",
        message: `${current.path} saved (${source}).`,
      });
      await load(current.id);
      toast.success("Saved");
    } catch (err) {
      toast.error(err?.message || "Could not save the file");
    } finally {
      setBusy("");
    }
  };

  const applyAI = async (mode) => {
    if (!current) return;
    if (mode === "edit" && instruction.trim().length < 3) {
      toast.error("Describe the change first");
      return;
    }
    setBusy("ai");
    try {
      const res = await aiEdit({ data: { bot_id: botId, path: current.path, instruction: instruction.trim() || "Regenerate", mode } });
      setDraft(res.content);
      setDirty(true);
      setInstruction("");
      toast.success("AI updated the file — review and save");
    } catch (err) {
      toast.error(err?.message || "AI edit failed");
    } finally {
      setBusy("");
    }
  };

  const addFile = async () => {
    const path = newPath.trim().replace(/^\/+/, "");
    if (!path) return;
    if (files.some((f) => f.path === path)) {
      toast.error("That file already exists");
      return;
    }
    try {
      const created = await base44.entities.BotFile.create({
        bot_id: botId,
        path,
        content: path.endsWith(".py") ? "# new module\n" : "",
        language: path.endsWith(".py") ? "python" : "text",
        version: 1,
      });
      setNewPath("");
      await load(created.id);
    } catch (err) {
      toast.error(err?.message || "Could not add the file");
    }
  };

  const renameFile = async () => {
    const path = renaming.trim().replace(/^\/+/, "");
    if (!current || !path) return;
    try {
      await base44.entities.BotFile.update(current.id, { path });
      setRenaming("");
      await load(current.id);
      toast.success("Renamed");
    } catch (err) {
      toast.error(err?.message || "Could not rename");
    }
  };

  const deleteFile = async () => {
    if (!current) return;
    if (!window.confirm(`Delete ${current.path}?`)) return;
    try {
      await base44.entities.BotFile.delete(current.id);
      await base44.entities.BotEvent.create({
        bot_id: botId,
        kind: "code_updated",
        level: "warn",
        message: `${current.path} deleted.`,
      });
      await load();
    } catch (err) {
      toast.error(err?.message || "Could not delete");
    }
  };

  const openVersions = async () => {
    if (!current) return;
    const page = await base44.entities.BotFileVersion.filter({ bot_id: botId, path: current.path }, { sort: "-created_date", limit: 20 });
    setVersions(page.items || []);
    setShowVersions(true);
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading project…
      </div>
    );
  }

  if (!bot) {
    return <p className="text-sm text-muted-foreground">Bot not found.</p>;
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to="/bots/$botId" params={{ botId }} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> {bot.name}
        </Link>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => downloadZip(files.map((f) => ({ path: f.path, content: f.content })), bot.name)}
            disabled={!files.length}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-medium transition hover:border-violet-500/40 disabled:opacity-40"
          >
            <Download className="h-3.5 w-3.5" /> Download project
          </button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[230px_1fr]">
        <aside className="rounded-2xl border border-border bg-card/60 p-2">
          <p className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
            Files · {files.length}
          </p>
          <div className="max-h-[520px] space-y-0.5 overflow-y-auto thin-scroll">
            {files.map((f) => (
              <button
                key={f.id}
                onClick={() => pick(f)}
                className={`flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left font-mono text-[11px] transition ${
                  f.id === selected ? "bg-violet-500/15 text-violet-200" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"
                }`}
              >
                <FileCode2 className="h-3 w-3 shrink-0" />
                <span className="truncate">{f.path}</span>
              </button>
            ))}
            {files.length === 0 && <p className="px-2 py-3 text-[11px] text-muted-foreground">No files yet.</p>}
          </div>
          <div className="mt-2 flex gap-1 border-t border-border pt-2">
            <input
              value={newPath}
              onChange={(e) => setNewPath(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addFile()}
              placeholder="cogs/new.py"
              className="min-w-0 flex-1 rounded-lg border border-input bg-background px-2 py-1.5 font-mono text-[11px] outline-none focus:border-violet-500/60"
            />
            <button onClick={addFile} aria-label="Add file" className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-violet-500 text-black">
              <Plus className="h-3.5 w-3.5" />
            </button>
          </div>
        </aside>

        <div className="min-w-0 space-y-3">
          {current ? (
            <>
              <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-card/60 px-3 py-2">
                {renaming ? (
                  <div className="flex flex-1 items-center gap-1">
                    <input
                      value={renaming}
                      onChange={(e) => setRenaming(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && renameFile()}
                      className="min-w-0 flex-1 rounded-lg border border-input bg-background px-2 py-1 font-mono text-[11px] outline-none"
                    />
                    <button onClick={renameFile} className="text-[11px] font-medium text-violet-300">Save</button>
                    <button onClick={() => setRenaming("")} className="text-muted-foreground"><X className="h-3.5 w-3.5" /></button>
                  </div>
                ) : (
                  <>
                    <span className="truncate font-mono text-xs text-foreground/90">{current.path}</span>
                    <span className="rounded-md bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">v{current.version || 1}</span>
                    <div className="ml-auto flex items-center gap-1">
                      <button onClick={() => setRenaming(current.path)} aria-label="Rename" className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground">
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button onClick={openVersions} aria-label="Version history" className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground">
                        <History className="h-3.5 w-3.5" />
                      </button>
                      <button onClick={deleteFile} aria-label="Delete file" className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-secondary hover:text-red-400">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => save(draft)}
                        disabled={busy === "save" || !dirty}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-violet-500 px-2.5 py-1.5 text-[11px] font-semibold text-black disabled:opacity-40"
                      >
                        {busy === "save" ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />} Save
                      </button>
                    </div>
                  </>
                )}
              </div>

              <CodeEditor
                value={draft}
                onChange={(v) => {
                  setDraft(v);
                  setDirty(true);
                }}
                ariaLabel={`Edit ${current.path}`}
              />

              <div className="rounded-2xl border border-violet-500/25 bg-violet-500/[0.06] p-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-3.5 w-3.5 text-violet-300" />
                  <p className="text-xs font-semibold text-violet-200">Ask AI to change this file</p>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <input
                    value={instruction}
                    onChange={(e) => setInstruction(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && applyAI("edit")}
                    placeholder="Add a /slowmode command with a duration option…"
                    className="min-w-0 flex-1 rounded-lg border border-input bg-background px-2.5 py-2 text-xs outline-none focus:border-violet-500/60"
                  />
                  <button
                    onClick={() => applyAI("edit")}
                    disabled={busy === "ai"}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-violet-500 px-3 py-2 text-[11px] font-semibold text-black disabled:opacity-60"
                  >
                    {busy === "ai" ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />} Apply
                  </button>
                  <button
                    onClick={() => applyAI("regenerate")}
                    disabled={busy === "ai"}
                    className="rounded-lg border border-border px-3 py-2 text-[11px] font-medium text-muted-foreground hover:text-foreground disabled:opacity-60"
                  >
                    Regenerate file
                  </button>
                </div>
                <p className="mt-2 text-[10px] text-muted-foreground">
                  AI edits are suggestions — review the diff in the editor and save to keep them.
                </p>
              </div>
            </>
          ) : (
            <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
              No files yet. Generate the bot from its order, or add a file on the left.
            </div>
          )}
        </div>
      </div>

      {showVersions && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowVersions(false)} />
          <div className="relative w-full max-w-lg rounded-2xl border border-border bg-card p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">Version history · {current?.path}</p>
              <button onClick={() => setShowVersions(false)} aria-label="Close"><X className="h-4 w-4 text-muted-foreground" /></button>
            </div>
            <div className="mt-3 max-h-80 space-y-2 overflow-y-auto thin-scroll">
              {versions.length === 0 && <p className="text-xs text-muted-foreground">No earlier versions yet.</p>}
              {versions.map((v) => (
                <div key={v.id} className="flex items-center gap-3 rounded-xl border border-border p-2.5">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium">v{v.version} · {v.source || "manual"}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {v.created_date ? new Date(v.created_date).toLocaleString("en-US") : ""} · {v.content?.length || 0} chars
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setDraft(v.content || "");
                      setDirty(true);
                      setShowVersions(false);
                      toast.success("Version loaded — save to restore");
                    }}
                    className="rounded-lg bg-violet-500 px-2.5 py-1.5 text-[11px] font-semibold text-black"
                  >
                    Restore
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}