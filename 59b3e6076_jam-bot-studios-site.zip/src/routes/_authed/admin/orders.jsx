import { useEffect, useState } from "react";
import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { Loader2, Search, ArrowRight } from "lucide-react";
import { base44 } from "@/api/base44Client";
import StatusPill from "@/components/StatusPill";

export const Route = createFileRoute("/_authed/admin/orders")({
  head: () => ({ meta: [{ title: "Orders & tickets — Jam Bot Studios" }] }),
  beforeLoad: ({ context }) => {
    if (context?.user && context.user.role !== "admin") throw redirect({ to: "/portfolio" });
  },
  component: AdminOrders,
});

const FILTERS = [
  ["all", "All"],
  ["pending", "Pending"],
  ["accepted", "Accepted"],
  ["in_development", "In development"],
  ["testing", "Testing"],
  ["completed", "Completed"],
  ["denied", "Denied"],
];

function AdminOrders() {
  const [orders, setOrders] = useState(null);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");

  useEffect(() => {
    base44.entities.BotOrder.list({ sort: "-created_date", limit: 100 })
      .then((page) => setOrders(page.items || []))
      .catch(() => setOrders([]));
  }, []);

  const visible = (orders || []).filter((o) => {
    const matchesStatus = filter === "all" || o.status === filter;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q ||
      o.bot_name?.toLowerCase().includes(q) ||
      o.order_code?.toLowerCase().includes(q) ||
      o.discord_username?.toLowerCase().includes(q) ||
      o.created_by?.toLowerCase().includes(q);
    return matchesStatus && matchesQuery;
  });

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Orders & tickets</h1>
          <p className="mt-1 text-sm text-muted-foreground">Every request, its ticket and its build status.</p>
        </div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search bot, code or user"
            className="w-64 rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-xs outline-none focus:border-violet-500/60"
          />
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-1.5">
        {FILTERS.map(([key, label]) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            className={`rounded-lg px-3 py-1.5 text-[11px] font-medium transition ${
              filter === key ? "bg-violet-500/15 text-violet-200 ring-1 ring-inset ring-violet-400/25" : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {orders === null ? (
        <div className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading orders…
        </div>
      ) : visible.length === 0 ? (
        <p className="mt-8 rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          No orders match this view.
        </p>
      ) : (
        <div className="mt-5 overflow-hidden rounded-2xl border border-border">
          <table className="w-full text-left text-sm">
            <thead className="bg-secondary/50 text-[10px] uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-2.5 font-medium">Order</th>
                <th className="hidden px-4 py-2.5 font-medium sm:table-cell">Customer</th>
                <th className="px-4 py-2.5 font-medium">Status</th>
                <th className="hidden px-4 py-2.5 font-medium md:table-cell">Submitted</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border bg-card/40">
              {visible.map((o) => (
                <tr key={o.id} className="transition hover:bg-secondary/30">
                  <td className="px-4 py-3">
                    <p className="font-medium">{o.bot_name}</p>
                    <p className="font-mono text-[10px] text-muted-foreground">{o.order_code}</p>
                  </td>
                  <td className="hidden px-4 py-3 text-xs text-muted-foreground sm:table-cell">
                    {o.discord_username || "—"}
                    <span className="block text-[10px] opacity-70">{o.created_by}</span>
                  </td>
                  <td className="px-4 py-3"><StatusPill status={o.status} /></td>
                  <td className="hidden px-4 py-3 text-xs text-muted-foreground md:table-cell">
                    {o.created_date ? new Date(o.created_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link
                      to="/orders/$orderId"
                      params={{ orderId: o.id }}
                      className="inline-flex items-center gap-1 text-xs font-medium text-violet-300 hover:text-violet-200"
                    >
                      Open <ArrowRight className="h-3 w-3" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}