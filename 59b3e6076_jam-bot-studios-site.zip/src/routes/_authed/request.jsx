import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Paperclip, Send, Sparkles, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { submitOrder } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/request")({
  head: () => ({ meta: [{ title: "Request a bot — Jam Bot Studios" }] }),
  component: RequestPage,
});

function RequestPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const submit = useServerFn(submitOrder);
  const [form, setForm] = useState({
    bot_name: "",
    discord_username: "",
    description: "",
    features: "",
    server_id: "",
    extra_requirements: "",
  });
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const onFiles = async (e) => {
    const picked = Array.from(e.target.files || []).slice(0, 6);
    if (!picked.length) return;
    setUploading(true);
    try {
      const uploaded = [];
      for (const file of picked) {
        if (file.size > 8 * 1024 * 1024) continue;
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        uploaded.push(file_uri);
      }
      setFiles((f) => [...f, ...uploaded].slice(0, 6));
    } catch {
      setError("One of the files could not be uploaded.");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSending(true);
    try {
      const result = await submit({
        data: {
          bot_name: form.bot_name.trim(),
          description: form.description.trim(),
          features: form.features.trim(),
          server_id: form.server_id.trim(),
          extra_requirements: form.extra_requirements.trim(),
          discord_username: form.discord_username.trim(),
          reference_files: files,
        },
      });
      navigate({ to: "/orders/$orderId", params: { orderId: result.id } });
    } catch (err) {
      setError(err?.message || "Your request could not be sent. Please try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="flex items-center gap-2">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-violet-200">
          <Sparkles className="h-3 w-3" /> New request
        </span>
      </div>
      <h1 className="mt-4 text-3xl font-semibold tracking-tight">Request a Discord bot</h1>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        Tell us what the bot should do. You'll get a private ticket with an order ID, a price and a timeline — and you
        can talk to the studio there.
      </p>

      <form onSubmit={onSubmit} className="mt-8 space-y-5 rounded-2xl border border-border bg-card/60 p-5 sm:p-7">
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">Bot name *</span>
            <input
              required
              minLength={2}
              value={form.bot_name}
              onChange={set("bot_name")}
              placeholder="Aegis"
              className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-violet-500/60"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">Your Discord username</span>
            <input
              value={form.discord_username}
              onChange={set("discord_username")}
              placeholder="bestofjam77"
              className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-violet-500/60"
            />
          </label>
        </div>

        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-foreground">What should it do? *</span>
          <textarea
            required
            minLength={10}
            rows={4}
            value={form.description}
            onChange={set("description")}
            placeholder="A moderation bot for a 12k-member gaming server. It should warn, mute and ban with a review log, and auto-detect spam raids."
            className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-violet-500/60"
          />
        </label>

        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-foreground">Features and commands</span>
          <textarea
            rows={4}
            value={form.features}
            onChange={set("features")}
            placeholder={"/warn, /mute, /ban, /case view, raid shield with a review panel, log channel setup"}
            className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-violet-500/60"
          />
        </label>

        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">Discord server ID (optional)</span>
            <input
              value={form.server_id}
              onChange={set("server_id")}
              placeholder="123456789012345678"
              className="w-full rounded-xl border border-input bg-background px-3 py-2.5 font-mono text-sm outline-none focus:border-violet-500/60"
            />
          </label>
          <div className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">Reference files or screenshots</span>
            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-input bg-background px-3 py-2.5 text-sm text-muted-foreground transition hover:border-violet-500/40 hover:text-foreground">
              {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Paperclip className="h-4 w-4" />}
              {files.length ? `${files.length} file(s) attached` : "Attach up to 6 files"}
              <input type="file" multiple className="hidden" onChange={onFiles} accept="image/*,.pdf,.txt,.json,.py" />
            </label>
            <p className="mt-1 text-[10px] text-muted-foreground">Uploaded files are stored privately.</p>
          </div>
        </div>

        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-foreground">Anything else?</span>
          <textarea
            rows={2}
            value={form.extra_requirements}
            onChange={set("extra_requirements")}
            placeholder="Deadline, budget, hosting preference…"
            className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-violet-500/60"
          />
        </label>

        {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300">{error}</p>}

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-5">
          <p className="text-[11px] text-muted-foreground">
            Signed in as {user?.email}. Never share a bot token or your Discord password.
          </p>
          <button
            type="submit"
            disabled={sending}
            className="inline-flex items-center gap-2 rounded-xl bg-violet-500 px-5 py-2.5 text-sm font-semibold text-black transition hover:bg-violet-400 disabled:opacity-60"
          >
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            {sending ? "Sending…" : "Submit request"}
          </button>
        </div>
      </form>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        {[
          ["1", "Submit", "You get an order ID and a private ticket."],
          ["2", "Plan", "We reply with price, timeline and questions."],
          ["3", "Build", "Track progress until your bot is delivered."],
        ].map(([n, title, copy]) => (
          <div key={n} className="rounded-xl border border-border bg-card/40 p-4">
            <span className="grid h-6 w-6 place-items-center rounded-full bg-violet-500/15 text-[11px] font-semibold text-violet-300">
              {n}
            </span>
            <p className="mt-2 flex items-center gap-1 text-sm font-medium">
              <Check className="h-3.5 w-3.5 text-violet-400" /> {title}
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{copy}</p>
          </div>
        ))}
      </div>
    </div>
  );
}