import { useEffect, useState } from "react";
import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import {
  Bot as BotIcon,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ClipboardList,
  Clock,
  Wrench,
  ArrowRight,
  RefreshCw,
  Bell,
  Loader2,
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import StatusPill from "@/components/StatusPill";
import { refreshBots } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/dashboard")({
  head: () => ({ meta: [{ title: "Owner dashboard — Jam Bot Studios" }] }),
  beforeLoad: ({ context }) => {
    if (context?.user && context.user.role !== "admin") throw redirect({ to: "/portfolio" });
  },
  component: Dashboard,
});

const CARDS = [
  { key: "bots", label: "Bots created", icon: BotIcon, tone: "text-violet-300" },
  { key: "online", label: "Bots online", icon: CheckCircle2, tone: "text-emerald-300" },
  { key: "offline", label: "Bots offline", icon: XCircle, tone: "text-red-300" },
  { key: "error", label: "Bots in error", icon: AlertTriangle, tone: "text-orange-300" },
  { key: "orders", label: "Total orders", icon: ClipboardList, tone: "text-sky-300" },
  { key: "pending", label: "Pending review", icon: Clock, tone: "text-zinc-300" },
  { key: "dev", label: "In development", icon: Wrench, tone: "text-violet-300" },
  { key: "completed", label: "Completed", icon: CheckCircle2, tone: "text-emerald-300" },
];

function Dashboard() {
  const [counts, setCounts] = useState(null);
  const [bots, setBots] = useState([]);
  const [orders, setOrders] = useState([]);
  const [events, setEvents] = useState([]);
  const [notes, setNotes] = useState([]);
  const [syncing, setSyncing] = useState(false);
  const refresh = useServerFn(refreshBots);

  const load = async () => {
    const [botsAll, online, offline, error, ordersTotal, pending, dev, completed] = await Promise.all([
      base44.entities.Bot.count(),
      base44.entities.Bot.count({ status: "online" }),
      base44.entities.Bot.count({ status: "offline" }),
      base44.entities.Bot.count({ status: "error" }),
      base44.entities.BotOrder.count(),
      base44.entities.BotOrder.count({ status: "pending" }),
      base44.entities.BotOrder.count({ status: "in_development" }),
      base44.entities.BotOrder.count({ status: "completed" }),
    ]);
    setCounts({ bots: botsAll, online, offline, error, orders: ordersTotal, pending, dev, completed });

    const [botPage, orderPage, eventPage, notePage] = await Promise.all([
      base44.entities.Bot.list({ sort: "-created_date", limit: 12 }),
      base44.entities.BotOrder.list({ sort: "-created_date", limit: 6 }),
      base44.entities.BotEvent.list({ sort: "-created_date", limit: 8 }),
      base44.entities.Notification.filter({ audience: "owner" }, { sort: "-created_date", limit: 6 }),
    ]);
    setBots(botPage.items || []);
    setOrders(orderPage.items || []);
    setEvents(eventPage.items || []);
    setNotes(notePage.items || []);
  };

  useEffect(() => {
    (async () => {
      try {
        await refresh();
      } catch {
        /* statuses stay as stored */
      }
      await load();
    })();
    const unsub = base44.entities.Bot.subscribe(() => load());
    return unsub;
  }, []);

  const sync = async () => {
    setSyncing(true);
    try {
      await refresh();
      await load();
    } finally {
      setSyncing(false);
    }
  };

  const botName = (id) => bots.find((b) => b.id === id)?.name || "Bot";

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Owner dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">Everything at a glance — orders, builds and live bot health.</p>
        </div>
        <button
          onClick={sync}
          disabled={syncing}
          className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3.5 py-2 text-xs font-medium transition hover:border-violet-500/40 disabled:opacity-60"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${syncing ? "animate-spin" : ""}`} /> Refresh statuses
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {CARDS.map((c) => {
          const Icon = c.icon;
          const value = counts ? counts[c.key] : "—";
          return (
            <div key={c.key} className="rounded-2xl border border-border bg-card/60 p-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">{c.label}</span>
                <Icon className={`h-4 w-4 ${c.tone}`} />
              </div>
              <p className="mt-3 text-2xl font-semibold tracking-tight">{value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="rounded-2xl border border-border bg-card/60">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <h2 className="text-sm font-semibold">Live bot status</h2>
            <Link to="/bots" className="text-[11px] font-medium text-violet-300 hover:text-violet-200">
              Bot manager
            </Link>
          </div>
          {bots.length === 0 ? (
            <p className="p-6 text-xs text-muted-foreground">
              No bots yet — accept an order and generate one with AI.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-4 py-2 font-medium">Bot</th>
                    <th className="px-4 py-2 font-medium">Status</th>
                    <th className="hidden px-4 py-2 font-medium sm:table-cell">Last seen</th>
                    <th className="px-4 py-2" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {bots.map((b) => (
                    <tr key={b.id} className="transition hover:bg-secondary/30">
                      <td className="px-4 py-2.5">
                        <p className="font-medium">{b.name}</p>
                        <p className="font-mono text-[10px] text-muted-foreground">{b.discord_bot_id || "not linked"}</p>
                      </td>
                      <td className="px-4 py-2.5"><StatusPill status={b.status} kind="bot" /></td>
                      <td className="hidden px-4 py-2.5 text-xs text-muted-foreground sm:table-cell">
                        {b.last_seen ? new Date(b.last_seen).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }) : "never"}
                      </td>
                      <td className="px-4 py-2.5 text-right">
                        <Link to="/bots/$botId" params={{ botId: b.id }} className="text-xs text-violet-300 hover:text-violet-200">
                          Manage
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="space-y-4">
          <div className="rounded-2xl border border-border bg-card/60">
            <div className="flex items-center gap-2 border-b border-border px-4 py-3">
              <Bell className="h-3.5 w-3.5 text-violet-300" />
              <h2 className="text-sm font-semibold">Notifications</h2>
            </div>
            <div className="max-h-64 space-y-1 overflow-y-auto thin-scroll p-2">
              {notes.length === 0 && <p className="p-3 text-xs text-muted-foreground">Nothing new.</p>}
              {notes.map((n) => (
                <Link
                  key={n.id}
                  to={n.link || "/admin/orders"}
                  className="block rounded-xl px-3 py-2 transition hover:bg-secondary/60"
                >
                  <p className={`text-xs ${n.read ? "text-muted-foreground" : "font-medium text-foreground"}`}>{n.title}</p>
                  <p className="mt-0.5 line-clamp-1 text-[11px] text-muted-foreground">{n.body}</p>
                </Link>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-card/60">
            <div className="flex items-center gap-2 border-b border-border px-4 py-3">
              <ClipboardList className="h-3.5 w-3.5 text-sky-300" />
              <h2 className="text-sm font-semibold">Latest orders</h2>
            </div>
            <div className="divide-y divide-border">
              {orders.length === 0 && <p className="p-4 text-xs text-muted-foreground">No orders yet.</p>}
              {orders.map((o) => (
                <Link
                  key={o.id}
                  to="/orders/$orderId"
                  params={{ orderId: o.id }}
                  className="flex items-center gap-3 px-4 py-2.5 transition hover:bg-secondary/30"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium">{o.bot_name}</p>
                    <p className="font-mono text-[10px] text-muted-foreground">{o.order_code}</p>
                  </div>
                  <StatusPill status={o.status} />
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
                </Link>
              ))}
            </div>
          </div>
        </section>
      </div>

      <section className="rounded-2xl border border-border bg-card/60">
        <div className="border-b border-border px-4 py-3">
          <h2 className="text-sm font-semibold">Recent activity</h2>
        </div>
        <ul className="divide-y divide-border">
          {events.length === 0 && <li className="p-4 text-xs text-muted-foreground">No events recorded yet.</li>}
          {events.map((e) => (
            <li key={e.id} className="flex flex-wrap items-center gap-3 px-4 py-2.5 text-xs">
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  e.level === "error" ? "bg-red-400" : e.level === "warn" ? "bg-amber-400" : "bg-violet-400"
                }`}
              />
              <span className="font-medium">{botName(e.bot_id)}</span>
              <span className="text-muted-foreground">{e.message}</span>
              <span className="ml-auto text-[10px] text-muted-foreground">
                {e.created_date ? new Date(e.created_date).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : ""}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}