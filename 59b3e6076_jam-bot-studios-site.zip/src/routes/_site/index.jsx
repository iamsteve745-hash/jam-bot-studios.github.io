import { createFileRoute } from "@tanstack/react-router";
import PortfolioPage from "@/components/PortfolioPage";

export const Route = createFileRoute("/_site/")({
  head: () => ({
    meta: [
      { title: "Jam Bot Studios — Custom Discord bots, built and monitored" },
      {
        name: "description",
        content:
          "Jam Bot Studios builds custom Discord bots: moderation, tickets, onboarding, economy, slash commands and automation. Request a bot and track it in a private ticket.",
      },
    ],
  }),
  component: PortfolioPage,
});