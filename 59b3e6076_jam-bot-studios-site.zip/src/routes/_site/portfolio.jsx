import { createFileRoute } from "@tanstack/react-router";
import PortfolioPage from "@/components/PortfolioPage";

export const Route = createFileRoute("/_site/portfolio")({
  head: () => ({
    meta: [
      { title: "Portfolio — Jam Bot Studios" },
      {
        name: "description",
        content:
          "Moderation, ticket, training, session, application, logging, economy and custom slash command bots — the full Jam Bot Studios service list.",
      },
    ],
  }),
  component: PortfolioPage,
});