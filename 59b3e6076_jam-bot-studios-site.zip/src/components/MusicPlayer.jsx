import { useEffect, useRef, useState } from "react";
import { Waves, Play, Pause, SkipBack, SkipForward, ChevronUp, Volume2, Sparkles } from "lucide-react";
import { getEngine, TRACK_LIST } from "@/lib/ambientMusic";

export default function MusicPlayer() {
  const [playing, setPlaying] = useState(false);
  const [needsTap, setNeedsTap] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [track, setTrack] = useState(0);
  const [volume, setVolume] = useState(0.5);
  const engine = useRef(null);

  useEffect(() => {
    engine.current = getEngine();
    let cancelled = false;

    const attempt = async () => {
      try {
        await engine.current.play();
        if (!cancelled) {
          setPlaying(true);
          setNeedsTap(false);
        }
      } catch {
        if (!cancelled) setNeedsTap(true);
      }
    };

    attempt();

    const onGesture = () => {
      if (!engine.current.playing) attempt();
    };
    window.addEventListener("pointerdown", onGesture);
    window.addEventListener("keydown", onGesture);
    return () => {
      cancelled = true;
      window.removeEventListener("pointerdown", onGesture);
      window.removeEventListener("keydown", onGesture);
    };
  }, []);

  const toggle = async () => {
    if (playing) {
      engine.current.pause();
      setPlaying(false);
      return;
    }
    try {
      await engine.current.play();
      setPlaying(true);
      setNeedsTap(false);
    } catch {
      setNeedsTap(true);
    }
  };

  const changeTrack = (next) => {
    const i = ((next % TRACK_LIST.length) + TRACK_LIST.length) % TRACK_LIST.length;
    setTrack(i);
    engine.current.setTrack(i);
  };

  const onVolume = (v) => {
    setVolume(v);
    engine.current.setVolume(v);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col items-end gap-2 print:hidden">
      {expanded && (
        <div className="w-72 rounded-2xl border border-border bg-card/95 p-4 shadow-2xl shadow-black/60 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Calm mode</span>
            <Sparkles className="h-3.5 w-3.5 text-violet-400" />
          </div>
          <p className="mt-1 text-sm font-medium text-foreground">{TRACK_LIST[track].name}</p>
          <p className="text-xs text-muted-foreground">{TRACK_LIST[track].mood}</p>

          <div className="mt-3 flex items-center gap-1.5">
            <button
              onClick={() => changeTrack(track - 1)}
              aria-label="Previous track"
              className="grid h-8 w-8 place-items-center rounded-lg border border-border text-muted-foreground transition hover:border-violet-500/50 hover:text-foreground"
            >
              <SkipBack className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={toggle}
              aria-label={playing ? "Pause music" : "Play music"}
              className="grid h-9 w-9 place-items-center rounded-lg bg-violet-500 text-black transition hover:bg-violet-400"
            >
              {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
            <button
              onClick={() => changeTrack(track + 1)}
              aria-label="Next track"
              className="grid h-8 w-8 place-items-center rounded-lg border border-border text-muted-foreground transition hover:border-violet-500/50 hover:text-foreground"
            >
              <SkipForward className="h-3.5 w-3.5" />
            </button>
            <div className="ml-auto flex items-center gap-1.5">
              <Volume2 className="h-3.5 w-3.5 text-muted-foreground" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={volume}
                onChange={(e) => onVolume(Number(e.target.value))}
                aria-label="Volume"
                className="h-1 w-16 accent-violet-500"
              />
            </div>
          </div>

          <div className="mt-3 max-h-40 space-y-1 overflow-y-auto thin-scroll pr-1">
            {TRACK_LIST.map((t) => (
              <button
                key={t.index}
                onClick={() => changeTrack(t.index)}
                className={`flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-left text-xs transition ${
                  t.index === track ? "bg-violet-500/15 text-violet-200" : "text-muted-foreground hover:bg-secondary"
                }`}
              >
                <span>{t.name}</span>
                <span className="text-[10px] uppercase tracking-wider opacity-60">{String(t.index + 1).padStart(2, "0")}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center gap-1 rounded-full border border-border bg-card/95 p-1 pl-3 shadow-xl shadow-black/50 backdrop-blur-xl">
        <Waves className={`h-4 w-4 ${playing ? "text-violet-400" : "text-muted-foreground"}`} />
        <button onClick={toggle} className="px-1 text-left" aria-label={playing ? "Pause calm mode" : "Start calm mode"}>
          <span className="block text-xs font-medium text-foreground">Calm mode</span>
          <span className="block text-[10px] text-muted-foreground">
            {playing ? TRACK_LIST[track].name : needsTap ? "Tap to start audio" : "Paused"}
          </span>
        </button>
        <button
          onClick={toggle}
          className={`grid h-8 w-8 place-items-center rounded-full transition ${
            playing ? "bg-violet-500 text-black hover:bg-violet-400" : "bg-violet-500/20 text-violet-300 hover:bg-violet-500/30"
          }`}
          aria-label={playing ? "Pause" : "Play"}
        >
          {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
        </button>
        <button
          onClick={() => setExpanded((e) => !e)}
          className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground transition hover:text-foreground"
          aria-label={expanded ? "Hide player" : "Show player"}
        >
          <ChevronUp className={`h-4 w-4 transition-transform ${expanded ? "rotate-180" : ""}`} />
        </button>
      </div>
      {needsTap && !playing && (
        <span className="rounded-full bg-violet-500/15 px-3 py-1 text-[10px] font-medium uppercase tracking-widest text-violet-300 ring-1 ring-violet-500/30">
          Audio needs one tap
        </span>
      )}
    </div>
  );
}