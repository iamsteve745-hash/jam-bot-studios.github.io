import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Send, Loader2, MessageSquare } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { postTicketMessage } from "@/lib/server-fns";

export default function TicketThread({ orderId, isOwner }) {
  const [messages, setMessages] = useState([]);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const post = useServerFn(postTicketMessage);
  const endRef = useRef(null);

  const load = async () => {
    const page = await base44.entities.TicketMessage.filter({ order_id: orderId }, { sort: "created_date", limit: 200 });
    setMessages(page.items || []);
  };

  useEffect(() => {
    load();
    const unsub = base44.entities.TicketMessage.subscribe((event) => {
      if (event?.data?.order_id === orderId) load();
    });
    return unsub;
  }, [orderId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length]);

  const send = async (e) => {
    e.preventDefault();
    if (!body.trim()) return;
    setSending(true);
    setError("");
    try {
      await post({ data: { order_id: orderId, body: body.trim() } });
      setBody("");
      await load();
    } catch (err) {
      setError(err?.message || "Message could not be sent");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col rounded-2xl border border-border bg-card/60">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <MessageSquare className="h-4 w-4 text-violet-300" />
        <h3 className="text-sm font-semibold">Ticket conversation</h3>
        <span className="ml-auto text-[11px] text-muted-foreground">Private · only you and the studio</span>
      </div>

      <div className="max-h-[420px] min-h-[180px] space-y-3 overflow-y-auto thin-scroll px-4 py-4">
        {messages.length === 0 && (
          <p className="py-8 text-center text-xs text-muted-foreground">No messages yet — say hello.</p>
        )}
        {messages.map((m) => {
          const mine = isOwner ? m.author_role === "owner" : m.author_role === "customer";
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm ${mine ? "bg-violet-500/15 ring-1 ring-inset ring-violet-400/25" : "bg-secondary"}`}>
                <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  {m.author_role === "owner" ? "Studio" : m.author_name || "Customer"} ·{" "}
                  {m.created_date ? new Date(m.created_date).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : ""}
                </p>
                <p className="whitespace-pre-wrap leading-relaxed text-foreground">{m.body}</p>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      <form onSubmit={send} className="border-t border-border p-3">
        {error && <p className="mb-2 text-xs text-red-400">{error}</p>}
        <div className="flex items-end gap-2">
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={2}
            placeholder="Write a message…"
            className="min-h-[44px] flex-1 resize-y rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:border-violet-500/60"
          />
          <button
            type="submit"
            disabled={sending || !body.trim()}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-violet-500 text-black transition hover:bg-violet-400 disabled:opacity-50"
            aria-label="Send message"
          >
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </button>
        </div>
      </form>
    </div>
  );
}