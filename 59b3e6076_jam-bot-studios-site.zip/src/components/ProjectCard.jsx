import {
  Shield,
  MessagesSquare,
  ClipboardList,
  GraduationCap,
  CalendarClock,
  Activity,
  Coins,
  Terminal,
  Zap,
  Bot,
} from "lucide-react";
import { ACCENTS } from "@/lib/siteDefaults";

const ICONS = {
  shield: Shield,
  messages: MessagesSquare,
  clipboard: ClipboardList,
  graduation: GraduationCap,
  calendar: CalendarClock,
  activity: Activity,
  coins: Coins,
  terminal: Terminal,
  zap: Zap,
  bot: Bot,
};

export default function ProjectCard({ project, featured = false }) {
  const Icon = ICONS[project.icon] || Bot;
  const accent = ACCENTS[project.accent] || ACCENTS.violet;
  const features = Array.isArray(project.features) ? project.features : [];

  return (
    <article
      className={`group relative overflow-hidden rounded-2xl border border-border bg-card/70 p-5 transition duration-300 hover:-translate-y-0.5 hover:border-violet-500/30 hover:shadow-2xl hover:shadow-violet-950/40 ${
        featured ? "sm:p-6" : ""
      }`}
    >
      <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${accent.from} ${accent.to} opacity-0 transition-opacity duration-300 group-hover:opacity-100`} />
      <div className="relative">
        <div className="flex items-start justify-between gap-3">
          <span className={`grid h-11 w-11 place-items-center rounded-xl bg-secondary ring-1 ring-inset ${accent.ring} ${accent.text}`}>
            <Icon className="h-5 w-5" />
          </span>
          <span className="rounded-full border border-border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
            {project.category}
          </span>
        </div>

        <h3 className={`mt-4 font-semibold tracking-tight text-foreground ${featured ? "text-lg" : "text-base"}`}>
          {project.title}
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{project.description}</p>

        {features.length > 0 && (
          <ul className="mt-4 flex flex-wrap gap-1.5">
            {features.map((f) => (
              <li
                key={f}
                className="rounded-md bg-secondary/70 px-2 py-1 text-[11px] font-medium text-muted-foreground ring-1 ring-inset ring-border"
              >
                {f}
              </li>
            ))}
          </ul>
        )}
      </div>
    </article>
  );
}