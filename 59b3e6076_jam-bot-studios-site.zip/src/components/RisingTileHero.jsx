import { useEffect, useRef } from "react";
import { Link } from "@tanstack/react-router";
import * as THREE from "three";

const SETTINGS = {
  cols: 16,
  rows: 16,
  tileSize: 1,
  gap: 0.016,
  thickness: 0.34,
  gridSpin: 46.5,
  tileColor: "#1b1626",
  sideColor: "#120e1c",
  seamColor: "#04030a",
  paperGrain: 0.5,
  roughness: 0.92,
  iconLine: 0.022,
  printedShare: 0.55,
  pressedDepth: 0.49,
  seed: 7,
  labelInset: 0.09,
  frameWeight: 0.4,
  matchOn: true,
  matchGlow: 2.2,
  liftHeight: 0.62,
  liftTime: 0.75,
  lightRamp: 1.6,
  holdTime: 3,
  pauseTime: 0.9,
  idleFloat: 0.03,
  idleTilt: 1.2,
  idleSpeed: 0.35,
  glowColor: "#a855f7",
  pitGlow: 3.98,
  wallGlow: 1.6,
  blockGlow: 0.21,
  wallGlowHeight: 0.1,
  pitLight: 17.5,
  volLight: 0.32,
  volSource: 0.63,
  volHeight: 2.4,
  volFade: 1.05,
  volSoft: 0.14,
  volStreaks: 0.61,
  volStreakScale: 9,
  volDrift: 0.41,
  volSteps: 80,
  keyLight: 1.8,
  keyAngle: 145,
  keyHeight: 73,
  ambient: 3,
  shadowSoft: 20,
  camTilt: 58.5,
  camDistance: 10.35,
  fov: 32,
  camX: 0,
  camY: 0,
  background: "#060409",
  exposure: 1,
  dpr: 1.6,
  maxPixels: 2.6,
};

function mount(root, canvas, statusText, statusEl, copyRef) {
  const opt = { ...SETTINGS };
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.shadowMap.autoUpdate = false;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(opt.fov, 1, 0.1, 200);
  camera.up.set(0, 0, 1);
  const world = new THREE.Group();
  scene.add(world);

  const key = new THREE.DirectionalLight(0xffffff, 2);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.bias = -0.0004;
  Object.assign(key.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 0.5, far: 40 });
  const ambient = new THREE.HemisphereLight(0xffffff, 0x2a2038, 0.5);
  scene.add(key, key.target, ambient);

  const MAXA = 3;
  const pitLights = [...Array(MAXA)].map(() => {
    const l = new THREE.PointLight(0xff5a0a, 0, 3, 2);
    world.add(l);
    return l;
  });

  const glowU = {
    uAC: { value: [...Array(MAXA)].map(() => new THREE.Vector2()) },
    uAL: { value: new Array(MAXA).fill(0) },
    uAZ: { value: new Array(MAXA).fill(0) },
    uHalf: { value: 0.5 },
    uThick: { value: 0.34 },
    uGlowC: { value: new THREE.Color() },
    uBlockGlow: { value: 0.12 },
    uWallGlow: { value: 1 },
    uWallH: { value: 0.2 },
    uPitGlow: { value: 3 },
  };

  const GLOW_GLSL = `
uniform vec2 uAC[${MAXA}]; uniform float uAL[${MAXA}], uAZ[${MAXA}];
uniform float uHalf, uThick, uWallGlow, uBlockGlow, uWallH, uPitGlow; uniform vec3 uGlowC;
varying vec3 vGP;
float rectDist(vec2 p, vec2 c, float h) { vec2 d = abs(p - c) - h; return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0); }`;

  const worldInvU = { value: new THREE.Matrix4() };
  const matchGlowU = { value: 2 };
  const glowC = new THREE.Color();

  function withGlow(mat, kind) {
    mat.onBeforeCompile = (sh) => {
      Object.assign(sh.uniforms, glowU);
      sh.vertexShader = "varying vec3 vGP;\n" + sh.vertexShader.replace(
        "#include <begin_vertex>",
        "#include <begin_vertex>\n#ifdef USE_INSTANCING\nvGP = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz;\n#else\nvGP = (modelMatrix * vec4(transformed, 1.0)).xyz;\n#endif\nvGP = (uWorldInv * vec4(vGP, 1.0)).xyz;"
      );
      sh.vertexShader = "uniform mat4 uWorldInv;\n" + sh.vertexShader;
      sh.uniforms.uWorldInv = worldInvU;
      let add = "";
      if (kind === "top") {
        sh.uniforms.uMatchGlow = matchGlowU;
        sh.vertexShader =
          "attribute vec2 aCell; attribute float aMatch; varying vec2 vLocalUv; varying float vMatch;\n" +
          sh.vertexShader.replace(
            "#include <uv_vertex>",
            "#include <uv_vertex>\nvLocalUv = uv; vMatch = aMatch;\n#ifdef USE_MAP\nvMapUv = (uv + aCell) * 0.25;\n#endif"
          );
        sh.fragmentShader =
          "uniform float uMatchGlow; varying vec2 vLocalUv; varying float vMatch;\n" +
          sh.fragmentShader.replace(
            "#include <map_fragment>",
            `
        #ifdef USE_MAP
          vec4 sdc = texture2D(map, vMapUv);
          vec4 mc = texture2D(map, (vLocalUv + vec2(3.0, 0.0)) * 0.25);
          float mk = smoothstep(0.15, 0.6, vMatch);
          diffuseColor *= mix(sdc, mc, mk);
          float matchMask = smoothstep(0.08, 0.35, mc.r) * mk;
        #else
          float matchMask = 0.0;
        #endif`
          );
        add = "totalEmissiveRadiance += uGlowC * matchMask * uMatchGlow;";
      }
      if (kind === "side")
        add = `
      for (int i = 0; i < ${MAXA}; i++) {
        float d = abs(rectDist(vGP.xy, uAC[i], uHalf));
        float near = 1.0 - smoothstep(0.0, uHalf * 0.12, d);
        float wall = near * smoothstep(0.0, -uThick, vGP.z);
        float bottom = uAZ[i] - uThick;
        float rim = near * step(bottom - 0.001, vGP.z) * exp(-(vGP.z - bottom) / max(uWallH * uThick, 0.001));
        totalEmissiveRadiance += uGlowC * uAL[i] * (uWallGlow * wall * 0.8 + uBlockGlow * rim);
      }`;
      if (kind === "floor")
        add = `
      for (int i = 0; i < ${MAXA}; i++) {
        float d = rectDist(vGP.xy, uAC[i], uHalf);
        totalEmissiveRadiance += uGlowC * uPitGlow * uAL[i] * (1.0 - smoothstep(-uHalf * 0.15, uHalf * 0.08, d));
      }`;
      sh.fragmentShader = GLOW_GLSL + "\n" + sh.fragmentShader.replace("#include <emissivemap_fragment>", "#include <emissivemap_fragment>\n" + add);
    };
    mat.customProgramCacheKey = () => "rt-" + kind;
    return mat;
  }

  function seeded(n) {
    let s = (n * 9301 + 49297) % 233280;
    return () => ((s = (s * 9301 + 49297) % 233280) / 233280);
  }
  function paper(x, S, base, rnd) {
    x.fillStyle = base;
    x.fillRect(0, 0, S, S);
    const img = x.getImageData(0, 0, S, S);
    const d = img.data;
    const g = opt.paperGrain * 22;
    for (let k = 0; k < d.length; k += 4) {
      const n = (rnd() - 0.5) * g;
      d[k] += n;
      d[k + 1] += n;
      d[k + 2] += n;
    }
    x.putImageData(img, 0, 0);
  }
  const ATL = 4;
  const CELL = 512;
  const MATCH_CELL = 15;
  function frame(x, S, lw) {
    const m = S * opt.labelInset;
    x.lineWidth = lw * opt.frameWeight;
    x.strokeRect(m, m, S - 2 * m, S - 2 * m);
  }
  function drawCell(x, S, col, lw) {
    x.strokeStyle = col;
    x.fillStyle = col;
    x.lineCap = "butt";
    x.lineJoin = "miter";
    frame(x, S, lw);
  }
  function topTexture(printed) {
    const S = CELL;
    const c = document.createElement("canvas");
    c.width = c.height = S * ATL;
    const x = c.getContext("2d");
    const rnd = seeded(printed ? 3 : 5);
    paper(x, S * ATL, opt.tileColor, rnd);
    const lw = S * opt.iconLine;
    for (const k of [0, MATCH_CELL]) {
      x.save();
      x.translate((k % ATL) * S, Math.floor(k / ATL) * S);
      x.beginPath();
      x.rect(0, 0, S, S);
      x.clip();
      if (k === MATCH_CELL) drawCell(x, S, opt.glowColor, lw * 1.1);
      else if (!printed) {
        x.save();
        x.translate(0, lw * 0.35);
        drawCell(x, S, "rgba(255,255,255,0.10)", lw);
        x.restore();
        drawCell(x, S, `rgba(0,0,0,${opt.pressedDepth})`, lw);
      }
      x.restore();
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = renderer.capabilities.getMaxAnisotropy();
    return t;
  }
  function sideTexture() {
    const S = 128;
    const c = document.createElement("canvas");
    c.width = c.height = S;
    const x = c.getContext("2d");
    paper(x, S, opt.sideColor, seeded(9));
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }

  const sideMat = withGlow(new THREE.MeshStandardMaterial({ roughness: 0.9, metalness: 0 }), "side");
  const topMats = [
    withGlow(new THREE.MeshStandardMaterial({ roughness: 0.9 }), "top"),
    withGlow(new THREE.MeshStandardMaterial({ roughness: 0.9 }), "top"),
  ];
  const floorMat = withGlow(new THREE.MeshStandardMaterial({ roughness: 1, color: 0x000000 }), "floor");
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), floorMat);
  floor.receiveShadow = true;
  world.add(floor);

  const VOL_V = `uniform vec3 uBox; varying vec3 vP; void main() { vP = position * uBox; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;
  const VOL_F = `uniform vec3 uCam, uCol, uBox; uniform float uHalf, uB, uT, uD, uH, uFade, uSoft, uStreak, uStreakScale, uTime, uAmt; uniform int uSteps;
varying vec3 vP;
float h21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + 1.0), f.x), f.y); }
float boxMask(vec2 q, float h, float soft) { vec2 d = abs(q) - h; return 1.0 - smoothstep(-soft, soft, max(d.x, d.y)); }
vec2 hitBox(vec3 ro, vec3 rd, vec3 bmin, vec3 bmax) { vec3 inv = 1.0 / rd, t0 = (bmin - ro) * inv, t1 = (bmax - ro) * inv;
  vec3 tn = min(t0, t1), tf = max(t0, t1); return vec2(max(max(tn.x, tn.y), tn.z), min(min(tf.x, tf.y), tf.z)); }
void main() {
  vec3 ro = uCam, rd = normalize(vP - uCam);
  vec2 tv = hitBox(ro, rd, vec3(-uBox.xy * 0.5, 0.0), vec3(uBox.xy * 0.5, uBox.z));
  float t0 = max(tv.x, 0.0), t1 = tv.y;
  vec2 tb = hitBox(ro, rd, vec3(-uHalf, -uHalf, uB), vec3(uHalf, uHalf, uB + uT));
  if (tb.x < tb.y && tb.y > 0.0) t1 = min(t1, tb.x);
  float M = uHalf + 2.0 * uSoft * (1.0 + uH / uD);
  for (int k = 0; k < 4; k++) {
    float sx = (k == 0) ? 1.0 : (k == 1) ? -1.0 : 0.0, sy = (k == 2) ? 1.0 : (k == 3) ? -1.0 : 0.0;
    float a = (sx * ro.x + sy * ro.y) * uD - M * (uD + ro.z), b = (sx * rd.x + sy * rd.y) * uD - M * rd.z;
    if (abs(b) < 1e-6) { if (a > 0.0) discard; }
    else if (b > 0.0) t1 = min(t1, -a / b); else t0 = max(t0, -a / b);
  }
  if (t1 <= t0) discard;
  int steps = int(clamp(ceil((t1 - t0) / (uH / float(uSteps))), 4.0, float(uSteps)));
  float n = float(steps), dt = (t1 - t0) / n, t = t0 + dt * h21(gl_FragCoord.xy + fract(uTime)), sum = 0.0;
  for (int i = 0; i < 96; i++) {
    if (i >= steps) break;
    vec3 p = ro + rd * t; t += dt;
    if (p.z <= 0.0) continue;
    float k = uD / (uD + p.z);
    vec2 q0 = p.xy * k;
    float soft = uSoft * (1.0 + p.z / uD);
    float lit = boxMask(q0, uHalf, soft);
    if (p.z > uB) lit *= 1.0 - boxMask(p.xy * (uD + uB) / (uD + p.z), uHalf, soft);
    if (lit <= 0.001) continue;
    float str = mix(1.0, vnoise(q0 * uStreakScale / uHalf + vec2(uTime * 0.7, -uTime * 0.4)) * 1.6, uStreak);
    float fall = k * k * exp(-p.z / uFade) * (1.0 - smoothstep(uH * 0.6, uH, p.z));
    sum += lit * str * fall * dt;
  }
  gl_FragColor = vec4(uCol * sum * uAmt, 1.0);
}`;
  const volGeo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0, 0.5);
  const vols = [...Array(MAXA)].map(() => {
    const m = new THREE.Mesh(
      volGeo,
      new THREE.ShaderMaterial({
        vertexShader: VOL_V,
        fragmentShader: VOL_F,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        uniforms: {
          uCam: { value: new THREE.Vector3() },
          uCol: { value: new THREE.Color() },
          uBox: { value: new THREE.Vector3(1, 1, 1) },
          uHalf: { value: 0.5 },
          uB: { value: 0 },
          uT: { value: 0.3 },
          uD: { value: 1 },
          uH: { value: 2 },
          uFade: { value: 1 },
          uSoft: { value: 0.05 },
          uStreak: { value: 0.5 },
          uStreakScale: { value: 9 },
          uTime: { value: 0 },
          uAmt: { value: 0 },
          uSteps: { value: 40 },
        },
      })
    );
    m.visible = false;
    m.frustumCulled = false;
    m.renderOrder = 2;
    world.add(m);
    return m;
  });

  let volTime = 0;
  const camLocal = new THREE.Vector3();
  let gridFresh = true;
  let tiles = [];
  let texKey = "";
  let gridKey = "";
  let pitch = 1;
  let gCols = 16;
  let gRows = 16;
  let inst = [];
  let dirty = true;
  let W = 1;
  let H = 1;
  let quality = 1;
  let frames = 0;
  let frameSum = 0;
  let coverExt = 9;
  let autoTile = null;
  let autoT = 0;
  let autoPhase = "pause";
  let tapHold = 0;
  let pointer = null;
  let rawPointer = null;
  let idleT = 0;
  let last = performance.now();
  let onScreen = true;
  let drewLast = 0;
  let raf = 0;

  const ray = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
  const hit = new THREE.Vector3();
  const pv = new THREE.Vector3();
  const cornerNdc = [
    [-1, -1],
    [1, -1],
    [1, 1],
    [-1, 1],
  ];
  const cornerHit = new THREE.Vector3();

  function tileHash(a, b) {
    let h = Math.imul(a * 2 + 1000, 73856093) ^ Math.imul(b * 2 + 1000, 19349663) ^ Math.imul(opt.seed + 7, 83492791);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  function cover() {
    camera.updateMatrixWorld();
    let mx = 0;
    let my = 0;
    let far = 0;
    for (const [x, y] of cornerNdc) {
      ndc.set(x, y);
      ray.setFromCamera(ndc, camera);
      let d = ray.ray.distanceToPlane(plane);
      if (d === null || d > 60 * pitch) d = 60 * pitch;
      ray.ray.at(d, cornerHit);
      far = Math.max(far, Math.hypot(cornerHit.x, cornerHit.y));
      cornerHit.applyMatrix4(worldInvU.value);
      mx = Math.max(mx, Math.abs(cornerHit.x));
      my = Math.max(my, Math.abs(cornerHit.y));
    }
    coverExt = far;
    const need = (m, min) => {
      let n = Math.max(min, Math.ceil(2 * (m / pitch + 1.5)));
      if ((n - min) % 2) n++;
      return Math.min(n, 121);
    };
    gCols = need(mx, opt.cols);
    gRows = need(my, opt.rows);
  }

  function build() {
    const tk = JSON.stringify([opt.tileSize, opt.gap, opt.thickness, opt.tileColor, opt.sideColor, opt.paperGrain, opt.iconLine, opt.pressedDepth, opt.labelInset, opt.frameWeight, opt.glowColor]);
    if (tk !== texKey) {
      texKey = tk;
      gridKey = "";
      topMats.forEach((m) => m.map?.dispose());
      sideMat.map?.dispose();
      topMats[0].map = topTexture(true);
      topMats[1].map = topTexture(false);
      sideMat.map = sideTexture();
      topMats.forEach((m) => (m.needsUpdate = true));
      sideMat.needsUpdate = true;
    }
    const k = JSON.stringify([gCols, gRows, opt.tileSize, opt.gap, opt.thickness, opt.printedShare, opt.seed]);
    if (k === gridKey) return;
    gridKey = k;
    const old = new Map(tiles.map((t) => [t.a + "," + t.b, t]));
    inst.forEach((m) => {
      world.remove(m);
      m.geometry.dispose();
      m.dispose();
    });
    pitch = opt.tileSize;
    const s = opt.tileSize * (1 - opt.gap);
    const T = opt.tileSize * opt.thickness;
    const n = gCols * gRows;
    inst = [0, 1].map((k2) => {
      const g = new THREE.BoxGeometry(s, s, T);
      g.setAttribute("aCell", new THREE.InstancedBufferAttribute(new Float32Array(n * 2), 2));
      g.setAttribute("aMatch", new THREE.InstancedBufferAttribute(new Float32Array(n), 1).setUsage(THREE.DynamicDrawUsage));
      const m = new THREE.InstancedMesh(g, [sideMat, sideMat, sideMat, sideMat, topMats[k2], sideMat], n);
      m.castShadow = m.receiveShadow = true;
      m.frustumCulled = false;
      m.count = 0;
      world.add(m);
      return m;
    });
    tiles = [];
    for (let j = 0; j < gRows; j++)
      for (let i = 0; i < gCols; i++) {
        const a = i - (gCols - 1) / 2;
        const b = j - (gRows - 1) / 2;
        const cx = a * pitch;
        const cy = b * pitch;
        const k2 = tileHash(a, b) < opt.printedShare ? 0 : 1;
        const m = inst[k2];
        const prev = old.get(a + "," + b);
        const t = { mesh: new THREE.Object3D(), inst: m, idx: m.count++, i, j, a, b, cx, cy, lift: 0, p: 0, target: 0 };
        m.geometry.attributes.aCell.setXY(t.idx, 0, ATL - 1);
        if (prev) {
          t.lift = prev.lift;
          t.p = prev.p;
          if (prev === autoTile) autoTile = t;
        }
        t.mesh.position.set(cx, cy, -T / 2);
        tiles.push(t);
      }
    floor.scale.set(gCols * pitch + 4, gRows * pitch + 4, 1);
    floor.position.z = -T - 0.002;
    gridFresh = true;
    dirty = true;
  }

  function layout() {
    W = Math.max(1, root.clientWidth);
    H = Math.max(1, root.clientHeight);
    const budget = Math.sqrt((opt.maxPixels * 1e6) / (W * H));
    renderer.setPixelRatio(Math.max(0.6, Math.min(window.devicePixelRatio || 1, opt.dpr, budget) * quality));
    renderer.setSize(W, H, false);
    camera.aspect = W / H;
    dirty = true;
  }

  function adapt(dtMs) {
    frames++;
    frameSum += dtMs;
    if (frames < 20) return;
    const avg = frameSum / frames;
    frames = 0;
    frameSum = 0;
    if (avg > 26 && quality > 0.55) {
      quality = Math.max(0.55, quality * 0.85);
      layout();
    } else if (avg < 15 && quality < 1) {
      quality = Math.min(1, quality * 1.08);
      layout();
    }
  }

  let statusSig = "";
  function setStatus(t) {
    const copy = copyRef?.current || {};
    const idle = copy.statusIdle || "Standby";
    const active = copy.statusActive || "Building · {id}";
    const txt = t ? active.replace("{id}", String(t.i).padStart(2, "0") + "·" + String(t.j).padStart(2, "0")) : idle;
    if (txt === statusSig) return;
    statusSig = txt;
    if (statusText) statusText.textContent = txt;
    statusEl?.classList.toggle("on", !!t);
  }

  function tileUnderPointer() {
    if (!pointer) return null;
    ndc.set((pointer[0] / W) * 2 - 1, 1 - (pointer[1] / H) * 2);
    ray.setFromCamera(ndc, camera);
    if (!ray.ray.intersectPlane(plane, hit)) return null;
    hit.applyMatrix4(worldInvU.value);
    const i = Math.round(hit.x / pitch + (gCols - 1) / 2);
    const j = Math.round(hit.y / pitch + (gRows - 1) / 2);
    if (i < 0 || j < 0 || i >= gCols || j >= gRows) return null;
    return tiles[j * gCols + i] || null;
  }

  function pickAuto() {
    const blocks = root.querySelectorAll(".hero-block");
    const crs = [...blocks].map((el) => el.getBoundingClientRect()).filter((r) => r.width);
    const rr = root.getBoundingClientRect();
    const pick = (reachX, reachY, pad) =>
      tiles.filter((t) => {
        if (t === autoTile) return false;
        pv.set(t.cx, t.cy, 0).applyMatrix4(world.matrixWorld).project(camera);
        if (Math.abs(pv.x) > reachX || Math.abs(pv.y) > reachY) return false;
        const sx = rr.left + ((pv.x + 1) / 2) * W;
        const sy = rr.top + ((1 - pv.y) / 2) * H;
        if (crs.some((cr) => sx > cr.left - pad && sx < cr.right + pad && sy > cr.top - pad && sy < cr.bottom + pad)) return false;
        return true;
      });
    let list = pick(0.6, 0.55, 90);
    if (!list.length) list = pick(0.85, 0.8, 60);
    if (!list.length) list = pick(0.85, 0.8, 0);
    if (!list.length) list = pick(0.85, 0.8, -1e6);
    return list[Math.floor(Math.random() * list.length)] || tiles[0];
  }

  const ease = (p) => p * p * (3 - 2 * p);

  function setup() {
    world.rotation.z = (opt.gridSpin * Math.PI) / 180;
    world.updateMatrixWorld();
    worldInvU.value.copy(world.matrixWorld).invert();
    camera.fov = opt.fov;
    const tl = (opt.camTilt * Math.PI) / 180;
    const tx = opt.camX * pitch;
    const ty = opt.camY * pitch;
    camera.position.set(tx, ty - Math.sin(tl) * opt.camDistance, Math.cos(tl) * opt.camDistance);
    camera.lookAt(tx, ty, 0);
    camera.updateProjectionMatrix();
    cover();
    build();
    const se = Math.min(coverExt + 2, 40);
    const sc = key.shadow.camera;
    if (sc.right !== se) {
      Object.assign(sc, { left: -se, right: se, top: se, bottom: -se, far: 2 * (12 + se) });
      sc.updateProjectionMatrix();
    }
    const a = (opt.keyAngle * Math.PI) / 180;
    const e = (opt.keyHeight * Math.PI) / 180;
    const kd = 12 + se;
    key.position.set(Math.cos(a) * Math.cos(e) * kd, Math.sin(a) * Math.cos(e) * kd, Math.sin(e) * kd);
    key.intensity = opt.keyLight;
    key.shadow.radius = opt.shadowSoft;
    ambient.intensity = opt.ambient;
    renderer.toneMappingExposure = opt.exposure;
    sideMat.roughness = opt.roughness;
    topMats.forEach((m) => (m.roughness = opt.roughness));
    floorMat.color.set(opt.seamColor);
  }

  function animate(dt, still, T) {
    const hovered = tileUnderPointer();
    if (tapHold > 0) tapHold -= dt;
    const useHover = !!pointer || tapHold > 0;
    if (!useHover && !still) {
      autoT -= dt;
      if (autoT <= 0) {
        if (autoPhase === "pause") {
          autoTile = pickAuto();
          autoPhase = "up";
          autoT = opt.liftTime + opt.holdTime;
        } else {
          autoPhase = "pause";
          autoT = opt.pauseTime + opt.liftTime;
        }
      }
    }
    let moved = false;
    let anyActive = false;
    const act = [];
    tiles.forEach((t) => {
      t.target = useHover ? (t === hovered ? 1 : 0) : autoPhase === "up" && t === autoTile ? 1 : 0;
      const step = still ? 1 : dt / Math.max(0.05, opt.liftTime);
      t.p = t.target > t.p ? Math.min(t.target, t.p + step) : Math.max(t.target, t.p - step);
      t.lift = ease(t.p);
      if (t.lift > 0.002) act.push(t);
      const active = t.lift > 0;
      if (active) anyActive = true;
      if (!active && t.rest && !gridFresh) return;
      t.rest = !active;
      const up = still ? 0 : t.lift * t.lift;
      const ph = idleT * opt.idleSpeed * Math.PI * 2 + t.a * 1.3 + t.b * 2.1;
      const bob = Math.sin(ph) * opt.idleFloat * opt.tileSize * up;
      const sway = ((opt.idleTilt * Math.PI) / 180) * up;
      t.mesh.rotation.set(Math.sin(ph * 0.73 + 1.1) * sway, Math.sin(ph * 0.61 + 2.3) * sway, 0);
      t.mesh.position.z = -T / 2 + t.lift * opt.liftHeight * opt.tileSize + bob;
      t.top = t.mesh.position.z + T / 2;
      const sig = t.lift * 7.3 + bob * 13 + (up ? ph : 0);
      if (sig !== t.sig || gridFresh) {
        t.sig = sig;
        moved = true;
        t.mesh.updateMatrix();
        t.inst.setMatrixAt(t.idx, t.mesh.matrix);
        t.inst.geometry.attributes.aMatch.array[t.idx] = opt.matchOn ? Math.min(1, t.lift) : 0;
      }
    });
    gridFresh = false;
    if (moved) {
      inst.forEach((m) => {
        m.instanceMatrix.needsUpdate = true;
        m.geometry.attributes.aMatch.needsUpdate = true;
      });
      renderer.shadowMap.needsUpdate = true;
    }
    volTime += still ? 0 : dt * opt.volDrift;
    idleT += still ? 0 : dt;
    matchGlowU.value = opt.matchGlow;
    act.sort((p, q) => q.lift - p.lift);
    act.length = Math.min(act.length, MAXA);
    setStatus(act[0] && act[0].lift > 0.5 && act[0].target > 0 ? act[0] : null);
    const gc = glowC.set(opt.glowColor);
    glowU.uHalf.value = (opt.tileSize * (1 - opt.gap)) / 2;
    glowU.uThick.value = T;
    glowU.uGlowC.value.copy(gc);
    glowU.uBlockGlow.value = opt.blockGlow;
    glowU.uWallGlow.value = opt.wallGlow;
    glowU.uWallH.value = opt.wallGlowHeight;
    glowU.uPitGlow.value = opt.pitGlow;
    for (let i = 0; i < MAXA; i++) {
      const t = act[i];
      const l = t ? Math.pow(Math.min(1, t.lift), opt.lightRamp) : 0;
      const z = t ? t.top : 0;
      if (t) glowU.uAC.value[i].set(t.cx, t.cy);
      glowU.uAL.value[i] = l;
      glowU.uAZ.value[i] = z;
      const pl = pitLights[i];
      pl.color.copy(gc);
      pl.intensity = opt.pitLight * l;
      pl.distance = pitch * 2.2;
      if (t) pl.position.set(t.cx, t.cy, -T * 0.55);
      const v = vols[i];
      v.visible = !!t && opt.volLight > 0;
      if (t) {
        const u = v.material.uniforms;
        const half = (opt.tileSize * (1 - opt.gap)) / 2;
        const D = opt.volSource * pitch;
        const Hh = opt.volHeight * pitch;
        const bw = 2 * ((half * (D + Hh)) / D + opt.volSoft * pitch * (1 + Hh / D) * 2);
        v.position.set(t.cx, t.cy, 0);
        v.scale.set(bw, bw, Hh);
        u.uBox.value.set(bw, bw, Hh);
        camLocal.copy(camera.position);
        world.worldToLocal(camLocal);
        camLocal.x -= t.cx;
        camLocal.y -= t.cy;
        u.uCam.value.copy(camLocal);
        u.uCol.value.copy(gc);
        u.uHalf.value = half;
        u.uB.value = z - T;
        u.uT.value = T;
        u.uD.value = D;
        u.uH.value = Hh;
        u.uFade.value = opt.volFade * pitch;
        u.uSoft.value = opt.volSoft * pitch;
        u.uStreak.value = opt.volStreaks;
        u.uStreakScale.value = opt.volStreakScale;
        u.uTime.value = volTime;
        u.uAmt.value = opt.volLight * l * 12;
        u.uSteps.value = Math.round(opt.volSteps);
      }
    }
    return moved || (!still && anyActive && opt.volLight > 0 && opt.volStreaks > 0 && opt.volDrift > 0);
  }

  function tick(now) {
    raf = requestAnimationFrame(tick);
    if (!onScreen) return;
    if (rawPointer) {
      const r = root.getBoundingClientRect();
      pointer = [rawPointer[0] - r.left, rawPointer[1] - r.top];
      rawPointer = null;
    }
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (dirty) setup();
    const moving = animate(dt, reduceMotion.matches, opt.tileSize * opt.thickness);
    if (moving || dirty) {
      if (dirty) renderer.shadowMap.needsUpdate = true;
      if (drewLast) adapt(now - drewLast);
      renderer.render(scene, camera);
      dirty = false;
      drewLast = now;
    } else drewLast = 0;
  }

  const overCopy = (e) => !!e.target.closest?.(".hero-block");

  function onPointerMove(e) {
    if (e.pointerType !== "mouse") return;
    if (overCopy(e)) {
      rawPointer = null;
      pointer = null;
      return;
    }
    rawPointer = [e.clientX, e.clientY];
  }
  function onPointerLeave() {
    pointer = null;
    rawPointer = null;
  }
  function onPointerDown(e) {
    if (e.pointerType !== "mouse" && !overCopy(e) && !e.target.closest?.(".cta")) {
      rawPointer = [e.clientX, e.clientY];
      tapHold = 2.5;
    }
  }
  root.addEventListener("pointermove", onPointerMove);
  root.addEventListener("pointerleave", onPointerLeave);
  root.addEventListener("pointerdown", onPointerDown);

  root.style.background = opt.background;
  scene.background = new THREE.Color(opt.background);

  const ro = new ResizeObserver(layout);
  ro.observe(root);
  const io = new IntersectionObserver(([en]) => {
    onScreen = en.isIntersecting;
    if (onScreen) {
      last = performance.now();
      dirty = true;
    }
  });
  io.observe(root);
  layout();
  raf = requestAnimationFrame(tick);

  return () => {
    cancelAnimationFrame(raf);
    ro.disconnect();
    io.disconnect();
    root.removeEventListener("pointermove", onPointerMove);
    root.removeEventListener("pointerleave", onPointerLeave);
    root.removeEventListener("pointerdown", onPointerDown);
    scene.traverse((o) => {
      o.geometry?.dispose?.();
      if (Array.isArray(o.material)) o.material.forEach((m) => m.dispose?.());
      else o.material?.dispose?.();
    });
    renderer.dispose();
  };
}

export default function RisingTileHero({
  eyebrow,
  tagline,
  statusIdle,
  statusActive,
  specs,
  titleTop,
  titleBottom,
  subtitle,
  ctaLabel,
  ctaTo,
}) {
  const rootRef = useRef(null);
  const canvasRef = useRef(null);
  const statusTextRef = useRef(null);
  const statusElRef = useRef(null);
  const copyRef = useRef({ statusIdle, statusActive });
  copyRef.current = { statusIdle, statusActive };

  useEffect(() => {
    if (!rootRef.current || !canvasRef.current) return;
    let cleanup;
    try {
      cleanup = mount(rootRef.current, canvasRef.current, statusTextRef.current, statusElRef.current, copyRef);
    } catch (err) {
      // WebGL unavailable: keep the copy readable over the static background.
      rootRef.current.style.background =
        "radial-gradient(50rem 30rem at 50% 110%, rgba(168,85,247,0.35), transparent 70%), #060409";
    }
    return () => cleanup?.();
  }, []);

  const specItems = (specs || "")
    .split(";")
    .map((v) => v.split("=").map((w) => w.trim()))
    .filter(([k]) => k);

  return (
    <section className="rt-hero" ref={rootRef} aria-labelledby="rt-title">
      <canvas className="gl" ref={canvasRef} aria-hidden="true" />
      <div className="hero">
        <div className="hero-top">
          <div className="hero-block">
            <p className="eyebrow">{eyebrow}</p>
            <p className="tagline">{tagline}</p>
            <p className="status" ref={statusElRef} aria-live="off">
              <span className="dot" />
              <span ref={statusTextRef}>{statusIdle}</span>
            </p>
          </div>
          {specItems.length > 0 && (
            <dl className="hero-block specs">
              {specItems.map(([k, v = ""]) => (
                <div key={k}>
                  <dt>{k}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
          )}
        </div>
        <div className="hero-bottom">
          <h1 className="hero-block hero-title" id="rt-title">
            <span>{titleTop}</span>
            <span>{titleBottom}</span>
          </h1>
          {subtitle && <p className="hero-block hero-sub">{subtitle}</p>}
          <Link className="hero-block cta" to={ctaTo || "/request"}>
            {ctaLabel}
          </Link>
        </div>
      </div>
    </section>
  );
}