export default function CodeEditor({ value, onChange, ariaLabel }) {
  const lines = String(value || "").split("\n").length;
  const numbers = Array.from({ length: lines }, (_, i) => i + 1).join("\n");

  return (
    <div className="relative flex h-[460px] overflow-hidden rounded-xl border border-border bg-[#0a0812]">
      <pre
        aria-hidden="true"
        className="h-full w-12 shrink-0 select-none overflow-hidden border-r border-border/60 bg-black/30 py-3 text-right font-mono text-[12px] leading-[1.6] text-muted-foreground/50"
      >
        {numbers}
      </pre>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        spellCheck={false}
        aria-label={ariaLabel || "Code"}
        wrap="off"
        className="h-full flex-1 resize-none bg-transparent p-3 font-mono text-[12px] leading-[1.6] text-foreground/90 outline-none"
      />
    </div>
  );
}