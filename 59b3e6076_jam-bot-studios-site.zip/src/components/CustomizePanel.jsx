import { useState } from "react";
import { X, Plus, Trash2, ArrowUp, ArrowDown, Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

const COPY_FIELDS = [
  { key: "hero_eyebrow", label: "Eyebrow" },
  { key: "hero_tagline", label: "Tagline" },
  { key: "hero_title_top", label: "Headline line 1" },
  { key: "hero_title_bottom", label: "Headline line 2" },
  { key: "hero_subtitle", label: "Hero paragraph", area: true },
  { key: "hero_specs", label: "Spec strip (label=value; …)" },
  { key: "cta_label", label: "Primary button label" },
  { key: "status_idle", label: "Status when idle" },
  { key: "status_active", label: "Status when active ({id})" },
  { key: "stack_title", label: "Stack heading" },
  { key: "footer_note", label: "Footer note", area: true },
];

const ICON_OPTIONS = ["shield", "messages", "clipboard", "graduation", "calendar", "activity", "coins", "terminal", "zap", "bot"];
const ACCENT_OPTIONS = ["violet", "blue", "fuchsia"];

export default function CustomizePanel({ content, contentId, projects, onClose, onSaved }) {
  const [draft, setDraft] = useState(content);
  const [list, setList] = useState(projects);
  const [removed, setRemoved] = useState([]);
  const [tab, setTab] = useState("copy");
  const [saving, setSaving] = useState(false);

  const set = (key, value) => setDraft((d) => ({ ...d, [key]: value }));
  const setStat = (i, key, value) =>
    setDraft((d) => {
      const stats = [...(d.stats || [])];
      stats[i] = { ...(stats[i] || {}), [key]: value };
      return { ...d, stats };
    });
  const setProject = (i, key, value) =>
    setList((l) => l.map((p, idx) => (idx === i ? { ...p, [key]: value } : p)));

  const move = (i, dir) => {
    const next = [...list];
    const j = i + dir;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    setList(next);
  };

  const addProject = () =>
    setList((l) => [
      ...l,
      { title: "New service", category: "Custom", description: "", features: [], icon: "bot", accent: "violet", sort: l.length },
    ]);

  const removeProject = (i) => {
    const p = list[i];
    if (p?.id) setRemoved((r) => [...r, p.id]);
    setList((l) => l.filter((_, idx) => idx !== i));
  };

  const save = async () => {
    setSaving(true);
    try {
      const payload = {};
      COPY_FIELDS.forEach(({ key }) => {
        payload[key] = draft[key] ?? "";
      });
      payload.stack = typeof draft.stack === "string" ? draft.stack.split(",").map((s) => s.trim()).filter(Boolean) : draft.stack || [];
      payload.stats = (draft.stats || []).filter((s) => s.label || s.value);

      if (contentId) await base44.entities.SiteContent.update(contentId, payload);
      else await base44.entities.SiteContent.create(payload);

      for (let i = 0; i < list.length; i++) {
        const p = list[i];
        const data = {
          title: p.title || "Untitled",
          category: p.category || "Custom",
          description: p.description || "",
          features: typeof p.features === "string" ? p.features.split(",").map((s) => s.trim()).filter(Boolean) : p.features || [],
          icon: p.icon || "bot",
          accent: p.accent || "violet",
          sort: i,
        };
        if (p.id) await base44.entities.PortfolioProject.update(p.id, data);
        else await base44.entities.PortfolioProject.create(data);
      }
      for (const id of removed) await base44.entities.PortfolioProject.delete(id);

      toast.success("Portfolio updated");
      onSaved();
    } catch (err) {
      toast.error(err?.message || "Could not save the portfolio");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex justify-end">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <aside className="relative flex h-full w-full max-w-xl flex-col border-l border-border bg-card shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div>
            <p className="text-sm font-semibold">Customize portfolio</p>
            <p className="text-[11px] text-muted-foreground">Every word, service and link on this page.</p>
          </div>
          <button onClick={onClose} aria-label="Close" className="text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex gap-1 border-b border-border px-5 py-2">
          {[
            ["copy", "Copy"],
            ["projects", "Services"],
          ].map(([key, label]) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                tab === key ? "bg-violet-500/15 text-violet-200" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto thin-scroll px-5 py-4">
          {tab === "copy" ? (
            <>
              {COPY_FIELDS.map(({ key, label, area }) => (
                <label key={key} className="block">
                  <span className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                    {label}
                  </span>
                  {area ? (
                    <textarea
                      rows={3}
                      value={draft[key] ?? ""}
                      onChange={(e) => set(key, e.target.value)}
                      className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-violet-500/60"
                    />
                  ) : (
                    <input
                      value={draft[key] ?? ""}
                      onChange={(e) => set(key, e.target.value)}
                      className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-violet-500/60"
                    />
                  )}
                </label>
              ))}

              <label className="block">
                <span className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Stack (comma separated)
                </span>
                <input
                  value={Array.isArray(draft.stack) ? draft.stack.join(", ") : draft.stack || ""}
                  onChange={(e) => set("stack", e.target.value)}
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-violet-500/60"
                />
              </label>

              <div>
                <span className="mb-2 block text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Stats
                </span>
                <div className="space-y-2">
                  {(draft.stats || []).map((s, i) => (
                    <div key={i} className="grid grid-cols-[1fr_1fr] gap-2">
                      <input
                        value={s.value || ""}
                        onChange={(e) => setStat(i, "value", e.target.value)}
                        placeholder="Value"
                        className="rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-violet-500/60"
                      />
                      <input
                        value={s.label || ""}
                        onChange={(e) => setStat(i, "label", e.target.value)}
                        placeholder="Label"
                        className="rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-violet-500/60"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-3">
              {list.map((p, i) => (
                <div key={p.id || i} className="rounded-xl border border-border bg-secondary/30 p-3">
                  <div className="flex items-center gap-2">
                    <input
                      value={p.title || ""}
                      onChange={(e) => setProject(i, "title", e.target.value)}
                      className="min-w-0 flex-1 rounded-lg border border-input bg-background px-2.5 py-1.5 text-sm font-medium outline-none focus:border-violet-500/60"
                    />
                    <button onClick={() => move(i, -1)} aria-label="Move up" className="text-muted-foreground hover:text-foreground">
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => move(i, 1)} aria-label="Move down" className="text-muted-foreground hover:text-foreground">
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => removeProject(i)} aria-label="Delete" className="text-muted-foreground hover:text-red-400">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-2">
                    <input
                      value={p.category || ""}
                      onChange={(e) => setProject(i, "category", e.target.value)}
                      placeholder="Category"
                      className="rounded-lg border border-input bg-background px-2.5 py-1.5 text-xs outline-none focus:border-violet-500/60"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <select
                        value={p.icon || "bot"}
                        onChange={(e) => setProject(i, "icon", e.target.value)}
                        className="rounded-lg border border-input bg-background px-2 py-1.5 text-xs outline-none focus:border-violet-500/60"
                      >
                        {ICON_OPTIONS.map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                      <select
                        value={p.accent || "violet"}
                        onChange={(e) => setProject(i, "accent", e.target.value)}
                        className="rounded-lg border border-input bg-background px-2 py-1.5 text-xs outline-none focus:border-violet-500/60"
                      >
                        {ACCENT_OPTIONS.map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <textarea
                    rows={2}
                    value={p.description || ""}
                    onChange={(e) => setProject(i, "description", e.target.value)}
                    placeholder="Description"
                    className="mt-2 w-full rounded-lg border border-input bg-background px-2.5 py-1.5 text-xs outline-none focus:border-violet-500/60"
                  />
                  <input
                    value={Array.isArray(p.features) ? p.features.join(", ") : p.features || ""}
                    onChange={(e) => setProject(i, "features", e.target.value)}
                    placeholder="Features, comma separated"
                    className="mt-2 w-full rounded-lg border border-input bg-background px-2.5 py-1.5 text-xs outline-none focus:border-violet-500/60"
                  />
                </div>
              ))}
              <button
                onClick={addProject}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-border py-2.5 text-xs font-medium text-muted-foreground transition hover:border-violet-500/40 hover:text-foreground"
              >
                <Plus className="h-3.5 w-3.5" /> Add a service
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border px-5 py-4">
          <p className="text-[11px] text-muted-foreground">Visible to everyone, editable by the owner only.</p>
          <button
            onClick={save}
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-xl bg-violet-500 px-4 py-2 text-sm font-semibold text-black transition hover:bg-violet-400 disabled:opacity-60"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
          </button>
        </div>
      </aside>
    </div>
  );
}