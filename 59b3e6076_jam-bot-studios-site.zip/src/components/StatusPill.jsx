const ORDER = {
  pending: { label: "Pending review", cls: "bg-zinc-500/15 text-zinc-300 ring-zinc-400/25", dot: "bg-zinc-400" },
  accepted: { label: "Accepted", cls: "bg-sky-500/15 text-sky-300 ring-sky-400/25", dot: "bg-sky-400" },
  in_development: { label: "In development", cls: "bg-violet-500/15 text-violet-300 ring-violet-400/25", dot: "bg-violet-400" },
  testing: { label: "Testing", cls: "bg-amber-500/15 text-amber-300 ring-amber-400/25", dot: "bg-amber-400" },
  completed: { label: "Completed", cls: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/25", dot: "bg-emerald-400" },
  denied: { label: "Denied", cls: "bg-red-500/15 text-red-300 ring-red-400/25", dot: "bg-red-400" },
};

const BOT = {
  online: { label: "Online", cls: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/25", dot: "bg-emerald-400", emoji: "🟢" },
  offline: { label: "Offline", cls: "bg-red-500/15 text-red-300 ring-red-400/25", dot: "bg-red-400", emoji: "🔴" },
  starting: { label: "Starting", cls: "bg-amber-500/15 text-amber-300 ring-amber-400/25", dot: "bg-amber-400", emoji: "🟡" },
  deploying: { label: "Deploying", cls: "bg-sky-500/15 text-sky-300 ring-sky-400/25", dot: "bg-sky-400", emoji: "🔵" },
  error: { label: "Error", cls: "bg-orange-500/15 text-orange-300 ring-orange-400/25", dot: "bg-orange-400", emoji: "🟠" },
};

export default function StatusPill({ status, kind = "order", withDot = true }) {
  const map = kind === "bot" ? BOT : ORDER;
  const s = map[status] || map.pending || map.offline;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium ring-1 ring-inset ${s.cls}`}
    >
      {withDot && <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />}
      {s.label}
    </span>
  );
}

export const BOT_STATUS = BOT;
export const ORDER_STATUS = ORDER;