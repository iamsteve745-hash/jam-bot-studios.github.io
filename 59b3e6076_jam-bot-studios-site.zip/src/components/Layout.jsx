import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutGrid,
  Send,
  ListChecks,
  Gauge,
  Bot,
  MessagesSquare,
  LogOut,
  LogIn,
  Menu,
  X,
  Sparkles,
  Users,
} from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import MusicPlayer from "@/components/MusicPlayer";

const NAV = [
  { label: "Portfolio", to: "/portfolio", icon: LayoutGrid },
  { label: "Request a Bot", to: "/request", icon: Send },
  { label: "My Orders", to: "/orders", icon: ListChecks },
  { label: "Owner Dashboard", to: "/dashboard", icon: Gauge, owner: true },
  { label: "Bot Manager", to: "/bots", icon: Bot, owner: true },
  { label: "Orders & Tickets", to: "/admin/orders", icon: MessagesSquare, owner: true },
  { label: "Team & staff", to: "/team", icon: Users, owner: true },
];

function NavList({ isAdmin, pathname, onNavigate }) {
  return (
    <nav className="flex flex-col gap-1">
      {NAV.filter((item) => !item.owner || isAdmin).map((item) => {
        const Icon = item.icon;
        const active = pathname === item.to || (item.to !== "/portfolio" && pathname.startsWith(item.to));
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${
              active
                ? "bg-violet-500/15 text-violet-100 ring-1 ring-inset ring-violet-400/25"
                : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"
            }`}
          >
            <Icon className={`h-4 w-4 ${active ? "text-violet-300" : "text-muted-foreground group-hover:text-foreground"}`} />
            <span className="font-medium">{item.label}</span>
            {item.owner && (
              <span className="ml-auto rounded-md bg-violet-500/15 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-violet-300">
                Owner
              </span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}

export default function Layout({ children }) {
  const { user, isAuthenticated, isLoadingAuth, navigateToLogin, logout } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const isAdmin = user?.role === "admin";

  const initials = (user?.full_name || user?.email || "JB")
    .split(/[\s@.]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((s) => s[0]?.toUpperCase())
    .join("");

  const account = (
    <div className="rounded-2xl border border-border bg-secondary/40 p-3">
      {isLoadingAuth ? (
        <div className="h-9 animate-pulse rounded-lg bg-secondary" />
      ) : isAuthenticated ? (
        <div className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-sky-500 text-xs font-semibold text-black">
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-medium text-foreground">{user?.full_name || user?.email}</p>
            <p className="truncate text-[10px] uppercase tracking-wider text-muted-foreground">
              {isAdmin ? "Owner" : "Customer"}
            </p>
          </div>
          <button
            onClick={() => logout()}
            aria-label="Sign out"
            className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground transition hover:bg-secondary hover:text-foreground"
          >
            <LogOut className="h-3.5 w-3.5" />
          </button>
        </div>
      ) : (
        <button
          onClick={() => navigateToLogin()}
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-violet-500 px-3 py-2 text-xs font-semibold text-black transition hover:bg-violet-400"
        >
          <LogIn className="h-3.5 w-3.5" /> Sign in
        </button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* mobile top bar */}
      <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur-xl lg:hidden">
        <button
          onClick={() => setOpen(true)}
          aria-label="Open menu"
          className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground"
        >
          <Menu className="h-4 w-4" />
        </button>
        <Link to="/portfolio" className="flex items-center gap-2">
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-violet-500 to-sky-500">
            <Sparkles className="h-3.5 w-3.5 text-black" />
          </span>
          <span className="text-sm font-semibold tracking-tight">Jam Bot Studios</span>
        </Link>
      </header>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70" onClick={() => setOpen(false)} />
          <aside className="relative flex h-full w-72 flex-col gap-4 border-r border-border bg-sidebar p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold tracking-tight">Jam Bot Studios</span>
              <button onClick={() => setOpen(false)} aria-label="Close menu" className="text-muted-foreground">
                <X className="h-4 w-4" />
              </button>
            </div>
            <NavList isAdmin={isAdmin} pathname={pathname} onNavigate={() => setOpen(false)} />
            <div className="mt-auto">{account}</div>
          </aside>
        </div>
      )}

      {/* desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-border bg-sidebar/80 p-4 backdrop-blur-xl lg:flex">
        <Link to="/portfolio" className="mb-6 flex items-center gap-2.5 px-2 pt-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-sky-500 shadow-lg shadow-violet-900/40">
            <Sparkles className="h-4 w-4 text-black" />
          </span>
          <span className="leading-tight">
            <span className="block text-sm font-semibold tracking-tight">Jam Bot Studios</span>
            <span className="block text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Discord bot lab</span>
          </span>
        </Link>
        <NavList isAdmin={isAdmin} pathname={pathname} />
        <div className="mt-auto space-y-3">
          <div className="rounded-xl border border-violet-500/20 bg-violet-500/[0.07] p-3">
            <p className="text-[11px] font-medium text-violet-200">Need something custom?</p>
            <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
              Send a request and get a build plan within a day.
            </p>
            <Link
              to="/request"
              className="mt-2 inline-flex items-center gap-1 text-[11px] font-semibold text-violet-300 hover:text-violet-200"
            >
              Start a request <Send className="h-3 w-3" />
            </Link>
          </div>
          {account}
        </div>
      </aside>

      <main className="lg:pl-64">
        <div className="mx-auto w-full max-w-6xl px-4 pb-24 pt-6 sm:px-6 lg:px-8 lg:pt-10">{children}</div>
      </main>

      <MusicPlayer />
    </div>
  );
}