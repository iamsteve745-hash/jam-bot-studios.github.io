import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Pencil, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import RisingTileHero from "@/components/RisingTileHero";
import ProjectCard from "@/components/ProjectCard";
import CustomizePanel from "@/components/CustomizePanel";
import { DEFAULT_CONTENT, DEFAULT_PROJECTS } from "@/lib/siteDefaults";

export default function PortfolioPage() {
  const { user } = useAuth();
  const [content, setContent] = useState(DEFAULT_CONTENT);
  const [contentId, setContentId] = useState(null);
  const [projects, setProjects] = useState(DEFAULT_PROJECTS);
  const [editing, setEditing] = useState(false);
  const isAdmin = user?.role === "admin";

  const load = async () => {
    try {
      const [rows, saved] = await Promise.all([
        base44.entities.SiteContent.list({ limit: 1 }),
        base44.entities.PortfolioProject.list({ sort: "sort", limit: 60 }),
      ]);
      const row = rows?.items?.[0] || (Array.isArray(rows) ? rows[0] : null);
      if (row) {
        setContentId(row.id);
        setContent({ ...DEFAULT_CONTENT, ...stripMeta(row) });
      }
      const list = saved?.items || saved || [];
      if (list.length) setProjects(list);
    } catch {
      // content not published yet — defaults stay on screen
    }
  };

  useEffect(() => {
    load();
  }, []);

  const featured = projects.slice(0, 3);

  return (
    <div className="space-y-16">
      <div className="-mx-4 sm:-mx-6 lg:-mx-8">
        <RisingTileHero
          eyebrow={content.hero_eyebrow}
          tagline={content.hero_tagline}
          statusIdle={content.status_idle}
          statusActive={content.status_active}
          specs={content.hero_specs}
          titleTop={content.hero_title_top}
          titleBottom={content.hero_title_bottom}
          subtitle={content.hero_subtitle}
          ctaLabel={content.cta_label}
          ctaTo="/request"
        />
      </div>

      <section>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-violet-300">Selected work</p>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">Bots that run real communities</h2>
          </div>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <button
                onClick={() => setEditing(true)}
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3.5 py-2 text-xs font-medium text-foreground transition hover:border-violet-500/40"
              >
                <Pencil className="h-3.5 w-3.5" /> Customize
              </button>
            )}
            <Link
              to="/request"
              className="inline-flex items-center gap-2 rounded-xl bg-violet-500 px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-violet-400"
            >
              {content.cta_label} <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((p) => (
            <ProjectCard key={p.id || p.title} project={p} featured />
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-xl font-semibold tracking-tight sm:text-2xl">Every kind of bot we build</h2>
          <span className="hidden text-xs text-muted-foreground sm:block">{projects.length} services</span>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.slice(3).map((p) => (
            <ProjectCard key={p.id || p.title} project={p} />
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card/60 p-6 sm:p-8">
        <div className="flex flex-wrap items-center gap-x-8 gap-y-3">
          <span className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            {content.stack_title}
          </span>
          <div className="flex flex-wrap gap-2">
            {(content.stack || []).map((s) => (
              <span
                key={s}
                className="rounded-lg border border-border bg-secondary/60 px-2.5 py-1 text-xs font-medium text-foreground/80"
              >
                {s}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-3">
        {(content.stats || []).map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-gradient-to-b from-card/80 to-card/40 p-6">
            <p className="text-3xl font-semibold tracking-tight text-foreground">{s.value}</p>
            <p className="mt-1 text-xs uppercase tracking-[0.16em] text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </section>

      <section className="relative overflow-hidden rounded-3xl border border-violet-500/25 bg-gradient-to-br from-violet-600/20 via-card to-sky-600/10 p-8 sm:p-12">
        <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-violet-500/25 blur-3xl" />
        <div className="relative max-w-xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-violet-200">
            <Sparkles className="h-3 w-3" /> Open for new builds
          </span>
          <h2 className="mt-4 text-2xl font-semibold tracking-tight sm:text-3xl">
            Tell us what your server needs.
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Describe the bot, list the commands, and we'll reply with a plan, a timeline and a fixed price — inside a
            private ticket.
          </p>
          <Link
            to="/request"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-violet-500 px-5 py-2.5 text-sm font-semibold text-black transition hover:bg-violet-400"
          >
            {content.cta_label} <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <footer className="border-t border-border pt-6 text-xs text-muted-foreground">{content.footer_note}</footer>

      {editing && isAdmin && (
        <CustomizePanel
          content={content}
          contentId={contentId}
          projects={projects}
          onClose={() => setEditing(false)}
          onSaved={async () => {
            setEditing(false);
            await load();
          }}
        />
      )}
    </div>
  );
}

function stripMeta(row) {
  const { id, created_date, updated_date, created_by_id, created_by, ...rest } = row;
  return rest;
}