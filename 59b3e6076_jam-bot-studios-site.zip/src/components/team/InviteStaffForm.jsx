import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Mail, ShieldPlus } from "lucide-react";
import { toast } from "sonner";
import { inviteStaff } from "@/lib/server-fns";

export default function InviteStaffForm({ onDone }) {
  const [email, setEmail] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const invite = useServerFn(inviteStaff);

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const result = await invite({ data: { email, note } });
      toast.success(
        result.status === "promoted"
          ? `${result.email} now has admin access`
          : `Invite sent to ${result.email}`
      );
      setEmail("");
      setNote("");
      await onDone();
    } catch (err) {
      setError(err?.message || "Could not add that person.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form
      onSubmit={submit}
      className="rounded-2xl border border-border bg-card/70 p-5 shadow-xl shadow-black/20"
    >
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-violet-500/15 text-violet-300 ring-1 ring-inset ring-violet-400/25">
          <ShieldPlus className="h-4 w-4" />
        </span>
        <div>
          <h2 className="text-sm font-semibold text-foreground">Add an admin</h2>
          <p className="text-[11px] text-muted-foreground">They can manage orders, bots and tickets.</p>
        </div>
      </div>

      <label className="mt-4 block">
        <span className="text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          Email address
        </span>
        <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-input bg-secondary/40 px-3">
          <Mail className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="teammate@example.com"
            className="w-full bg-transparent py-2.5 text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
          />
        </div>
      </label>

      <label className="mt-3 block">
        <span className="text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          What they help with <span className="normal-case tracking-normal opacity-60">(optional)</span>
        </span>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Tickets and customer replies"
          className="mt-1.5 w-full rounded-xl border border-input bg-secondary/40 px-3 py-2.5 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-violet-500/50"
        />
      </label>

      {error && (
        <p className="mt-3 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={busy || !email.trim()}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-violet-500 px-4 py-2.5 text-sm font-semibold text-black transition hover:bg-violet-400 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldPlus className="h-4 w-4" />}
        {busy ? "Adding…" : "Add as admin"}
      </button>

      <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
        They get an email invite. Only you can add or remove admins, and your own access can never be
        taken away.
      </p>
    </form>
  );
}