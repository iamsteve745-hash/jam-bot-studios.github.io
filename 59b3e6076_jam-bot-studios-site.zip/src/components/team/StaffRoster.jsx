import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Crown, Loader2, ShieldCheck, Trash2, Clock } from "lucide-react";
import { toast } from "sonner";
import { revokeStaff } from "@/lib/server-fns";

function Row({ children }) {
  return (
    <li className="flex items-center gap-3 border-b border-border/60 px-4 py-3 last:border-b-0">{children}</li>
  );
}

export default function StaffRoster({ team, onDone }) {
  const [busyEmail, setBusyEmail] = useState("");
  const revoke = useServerFn(revokeStaff);
  const admins = team.members.filter((m) => m.role === "admin");
  const customers = team.members.length - admins.length;

  const remove = async (email) => {
    if (!window.confirm(`Remove admin access for ${email}?`)) return;
    setBusyEmail(email);
    try {
      await revoke({ data: { email } });
      toast.success(`Admin access removed for ${email}`);
      await onDone();
    } catch (err) {
      toast.error(err?.message || "Could not remove access.");
    } finally {
      setBusyEmail("");
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card/70 shadow-xl shadow-black/20">
      <div className="flex items-center justify-between border-b border-border px-4 py-3.5">
        <h2 className="text-sm font-semibold text-foreground">Who has access</h2>
        <span className="text-[11px] text-muted-foreground">
          {admins.length} admin{admins.length === 1 ? "" : "s"} · {customers} customer{customers === 1 ? "" : "s"}
        </span>
      </div>

      <ul>
        <Row>
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-amber-500/15 text-amber-300 ring-1 ring-inset ring-amber-400/25">
            <Crown className="h-3.5 w-3.5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-foreground">{team.owner_email}</p>
            <p className="text-[11px] text-muted-foreground">Owner — final say on everything</p>
          </div>
          <span className="rounded-md bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber-300">
            Owner
          </span>
        </Row>

        {admins
          .filter((m) => (m.email || "").toLowerCase() !== team.owner_email.toLowerCase())
          .map((member) => (
            <Row key={member.id}>
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-violet-500/15 text-violet-300 ring-1 ring-inset ring-violet-400/25">
                <ShieldCheck className="h-3.5 w-3.5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">{member.name || member.email}</p>
                <p className="truncate text-[11px] text-muted-foreground">{member.email}</p>
              </div>
              {team.is_owner ? (
                <button
                  onClick={() => remove(member.email)}
                  disabled={busyEmail === member.email}
                  className="flex items-center gap-1 rounded-lg border border-border px-2 py-1 text-[11px] font-medium text-muted-foreground transition hover:border-red-500/40 hover:text-red-300 disabled:opacity-50"
                >
                  {busyEmail === member.email ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <Trash2 className="h-3 w-3" />
                  )}
                  Remove
                </button>
              ) : (
                <span className="rounded-md bg-violet-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-violet-300">
                  Admin
                </span>
              )}
            </Row>
          ))}

        {team.invites.map((invite) => (
          <Row key={invite.id}>
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-secondary text-muted-foreground ring-1 ring-inset ring-border">
              <Clock className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">{invite.email}</p>
              <p className="truncate text-[11px] text-muted-foreground">
                Invite sent{invite.note ? ` · ${invite.note}` : ""}
              </p>
            </div>
            {team.is_owner && (
              <button
                onClick={() => remove(invite.email)}
                disabled={busyEmail === invite.email}
                className="flex items-center gap-1 rounded-lg border border-border px-2 py-1 text-[11px] font-medium text-muted-foreground transition hover:border-red-500/40 hover:text-red-300 disabled:opacity-50"
              >
                {busyEmail === invite.email ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : (
                  <Trash2 className="h-3 w-3" />
                )}
                Cancel
              </button>
            )}
          </Row>
        ))}

        {admins.length === 1 && team.invites.length === 0 && (
          <Row>
            <p className="text-xs text-muted-foreground">
              No one else yet. Add an email on the left and they can start helping right away.
            </p>
          </Row>
        )}
      </ul>

      <p className="border-t border-border px-4 py-3 text-[11px] leading-relaxed text-muted-foreground">
        Removing access takes effect immediately. If you cancel an invite before they sign up, they may
        still appear here after accepting the original email — remove them again to drop their access.
      </p>
    </div>
  );
}